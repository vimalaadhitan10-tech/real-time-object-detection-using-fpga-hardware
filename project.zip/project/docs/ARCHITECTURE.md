# System Architecture

## 1. Overview

This document describes the hardware-software architecture for the
Real-Time CNN Object Detection system on the Xilinx Zynq-7000 XC7Z020.

---

## 2. Target Platform: ZedBoard (XC7Z020)

### Zynq-7000 SoC Resources (XC7Z020)
| Resource | Quantity |
|----------|----------|
| LUTs | 53,200 |
| LUTRAMs | 17,400 |
| Flip-Flops | 106,400 |
| BRAM_36 | 140 (4,536 Kb) |
| DSP48E1 | 220 |
| ARM Cortex-A9 (PS) | 2 cores @ up to 667 MHz |
| DDR3 RAM (ZedBoard) | 512 MB |
| PL-PS Clock | Configurable (typical: 100–200 MHz) |

### ZedBoard Peripherals Relevant to This Project
| Peripheral | Interface | Use |
|-----------|-----------|-----|
| HDMI TX | AXI-Stream VDMA | Detection overlay display |
| OV7670 Camera (FMC) | AXI-Stream | Live video input |
| USB-JTAG | JTAG | Bitstream programming |
| Ethernet | MII/RGMII | Optional remote access |
| USB-UART | PS UART | Debug console |
| DDR3 (512 MB) | PS DDR controller | Input/output buffers |

---

## 3. System Block Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Zynq-7000 XC7Z020                               │
│                                                                         │
│  ┌──────────────────────────────┐  ┌──────────────────────────────────┐ │
│  │   Processing System (PS)     │  │   Programmable Logic (PL)        │ │
│  │                              │  │                                  │ │
│  │  ┌────────────────────────┐  │  │  ┌──────────────────────────┐   │ │
│  │  │  ARM Cortex-A9 Core 0  │  │  │  │   CNN Accelerator IP     │   │ │
│  │  │  - Preprocessing       │  │  │  │   (conv_engine)          │   │ │
│  │  │  - App control         │  │  │  │   ┌──────────────────┐   │   │ │
│  │  │  - Postprocessing      │  │  │  │   │ 3×3 Conv Engine  │   │   │ │
│  │  │  - NMS                 │  │  │  │   │ DSP48E1 MACs     │   │   │ │
│  │  └────────────────────────┘  │  │  │   │ BRAM_36 Buffers  │   │   │ │
│  │                              │  │  │   └──────────────────┘   │   │ │
│  │  ┌────────────────────────┐  │  │  │   AXI4-Lite: Control     │   │ │
│  │  │  ARM Cortex-A9 Core 1  │  │  │  │   AXI4-Stream: Data      │   │ │
│  │  │  - DMA management      │  │  │  └──────────────────────────┘   │ │
│  │  │  - Interrupt handling  │  │  │                                  │ │
│  │  └────────────────────────┘  │  │  ┌──────────────────────────┐   │ │
│  │                              │  │  │   AXI DMA                │   │ │
│  │  ┌────────────────────────┐  │  │  │   MM2S: DDR→Accelerator  │   │ │
│  │  │   DDR3 Controller (PS) │◄─┼──┼──►  S2MM: Accelerator→DDR  │   │ │
│  │  │   512 MB               │  │  │  └──────────────────────────┘   │ │
│  │  └────────────────────────┘  │  │                                  │ │
│  │                              │  │  ┌──────────────────────────┐   │ │
│  │  PS-PL AXI Interconnect     │  │  │   AXI Interconnect       │   │ │
│  │  (GP0/GP1 Master ports)     │◄─┼──►  (SmartConnect / AXI IC) │   │ │
│  │                              │  │  └──────────────────────────┘   │ │
│  └──────────────────────────────┘  │                                  │ │
│                                    │  ┌──────────────────────────┐   │ │
│                                    │  │  (Optional) AXI VDMA     │   │ │
│                                    │  │  Camera → DDR → HDMI     │   │ │
│                                    │  └──────────────────────────┘   │ │
│                                    └──────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
        ↑ Camera (FMC/PCAM)                           ↓ HDMI TX
```

---

## 4. Inference Pipeline

```
Phase 1: Capture (ARM PS / Camera)
┌──────────────────────────────────────────────────┐
│ Camera: 640×480 BGR frame @ up to 30 FPS        │
│ File input: JPEG/PNG loaded via OpenCV          │
└───────────────────────┬──────────────────────────┘
                        │
Phase 2: Preprocessing (ARM Cortex-A9)
┌──────────────────────────────────────────────────┐
│ Resize:    640×480 → 416×416                    │
│ Normalize: [0,255] → [0.0, 1.0] (FP32)         │
│ Quantize:  FP32 → INT8 (scale + zero_point)    │
│ Layout:    HWC → CHW (for accelerator)          │
│ Copy:      ARM DDR → input DMA buffer           │
└───────────────────────┬──────────────────────────┘
                        │ AXI DMA (MM2S)
Phase 3: Convolution Acceleration (XC7Z020 PL)
┌──────────────────────────────────────────────────┐
│ CNN Accelerator:                                │
│  - Layer-by-layer convolution (pipelined)       │
│  - DSP48E1 for INT8 MAC operations              │
│  - BRAM_36 for weight storage                   │
│  - Local line buffers for activations           │
│ Control: AXI4-Lite registers                    │
│ Data: AXI4-Stream                               │
└───────────────────────┬──────────────────────────┘
                        │ AXI DMA (S2MM)
Phase 4: Postprocessing (ARM Cortex-A9)
┌──────────────────────────────────────────────────┐
│ Read output feature maps from DDR               │
│ Apply detection head (fully on ARM):            │
│  - Decode anchor boxes                          │
│  - Apply sigmoid activations                    │
│  - Filter by confidence threshold              │
│  - Non-Maximum Suppression (NMS)                │
│  - Scale boxes to original image                │
└───────────────────────┬──────────────────────────┘
                        │
Phase 5: Display (HDMI / UART)
┌──────────────────────────────────────────────────┐
│ Draw bounding boxes + labels on frame           │
│ Output via HDMI (ZedBoard HDMI TX)              │
│ Or: save result image / print to UART           │
└──────────────────────────────────────────────────┘
```

---

## 5. AXI Address Map (Planned)

> **Note:** Final addresses are assigned by Vivado during block design.
> These are planned addresses subject to change at synthesis time.

| Component | AXI4-Lite Base Address | Size |
|-----------|----------------------|------|
| Zynq PS (GP0 Master) | 0x4000_0000 | 1 GB |
| CNN Accelerator (AXI4-Lite) | 0x4300_0000 | 64 KB |
| AXI DMA | 0x4040_0000 | 64 KB |
| AXI VDMA (optional) | 0x4300_0000 | 64 KB |

### CNN Accelerator Register Map (AXI4-Lite)
| Offset | Register | Description |
|--------|----------|-------------|
| 0x00 | CTRL | bit[0]=start, bit[1]=done, bit[2]=idle |
| 0x04 | STATUS | bit[0]=busy, bit[1]=done, bit[2]=error |
| 0x08 | INPUT_ADDR | DDR address of input feature map |
| 0x0C | OUTPUT_ADDR | DDR address of output feature map |
| 0x10 | WEIGHT_ADDR | DDR address of weights |
| 0x14 | CONFIG_0 | IN_H[15:0], IN_W[31:16] |
| 0x18 | CONFIG_1 | IN_C[7:0], OUT_C[15:8], K[19:16], STRIDE[23:20] |
| 0x1C | SCALE | INT8 output scale factor (Q8.8) |

---

## 6. HLS Convolution Engine Architecture

### Interface Ports
```cpp
void conv_engine(
    hls::stream<ap_axis<8,0,0,0>> &s_axis_input,   // AXI-Stream input
    hls::stream<ap_axis<8,0,0,0>> &s_axis_output,  // AXI-Stream output
    int16_t weights[OUT_C][IN_C][K][K],             // Weight BRAM
    int32_t bias[OUT_C],                            // Bias BRAM
    int in_h, int in_w, int in_c,                  // AXI4-Lite config
    int out_c, int stride, int pad,                 // AXI4-Lite config
    int scale_factor                                // INT8 scale
);
```

### Dataflow Architecture
```
Input Stream → Line Buffer → Window Buffer → MAC Array → Accumulator → Output Stream
                                                ↑
                                        Weight BRAM
                                        (DSP48E1 MACs)
```

### Resource Estimates (Planned, 100 MHz target)
| Resource | Estimate | Budget |
|----------|----------|--------|
| DSP48E1 | ~64–128 | 220 |
| BRAM_36 | ~20–40 | 140 |
| LUT | ~8,000–15,000 | 53,200 |
| FF | ~10,000–20,000 | 106,400 |
| Latency | ~TBD cycles | — |

> Actual utilization pending Vitis HLS synthesis (tool not yet installed).

---

## 7. Software Architecture (ARM Cortex-A9)

```
main.c
  ├── initialize_platform()          // Cache, MMU, interrupt controller
  ├── cnn_accel_init()               // AXI4-Lite register check + reset
  ├── dma_init()                     // AXI DMA channel setup
  ├── frame_loop:
  │   ├── capture_frame()            // Camera VDMA or file read
  │   ├── preprocess_frame()         // Resize + normalize + INT8 quantize
  │   ├── dma_transfer_to_pl()       // Flush cache + start MM2S
  │   ├── cnn_accel_start()          // Write CTRL.start
  │   ├── wait_for_done()            // Poll STATUS or interrupt
  │   ├── dma_receive_from_pl()      // Start S2MM + invalidate cache
  │   ├── postprocess_detections()   // Decode + NMS
  │   └── display_results()          // HDMI overlay or UART print
  └── cleanup()
```

---

## 8. YOLOv5n Model Summary

| Property | Value |
|----------|-------|
| Parameters | 1.9 M |
| FLOPs (input 416×416) | 4.5 GFLOPs |
| COCO mAP@50 | 28.0% |
| COCO mAP@50:95 | 45.7% (from Ultralytics) |
| Input size | 416×416 (configurable: 320×320, 640×640) |
| Output | 3 scales × (5 + num_classes) anchors |
| Framework | PyTorch / Ultralytics |

### Model Compression Targets
| Technique | Target | Notes |
|-----------|--------|-------|
| INT8 QAT | ≤2% mAP drop | vs FP32 baseline |
| Structured pruning | ≤5% mAP drop | 30–50% weight sparsity |
| Combined | ≤2% mAP drop | INT8 + light pruning |

---

## 9. Design Decisions and Rationale

### Why YOLOv5n (not MobileNet-SSD)?
- YOLOv5n has a lower parameter count for comparable mAP on COCO
- Single-stage detector — simpler to map to FPGA pipeline
- Ultralytics provides excellent INT8 export + ONNX toolchain
- Directly supported by available literature (Saidani 2024, Huang 2025)

### Why Bare-metal (not Embedded Linux)?
- Lower latency (no OS overhead)
- Simpler deployment (no boot partition, rootfs, device tree)
- Deterministic timing for real-time inference
- Appropriate for a 3-month academic project
- Can be upgraded to PetaLinux later if camera pipeline requires it

### Why INT8 (not FP16)?
- XC7Z020 DSP48E1 supports 18×25-bit multiplications
- INT8 maps efficiently to DSP48E1 with packing
- INT8 is the quantization level targeted by the PPT explicitly
- Huang et al. (2025) demonstrates 27.2 FPS with INT8 on similar Zynq

### Why AXI DMA (not AXI Stream directly to PS)?
- AXI DMA provides scatter-gather and burst transfers
- Decouples PS memory bandwidth from PL computation
- Enables efficient ping-pong buffering between frames
