# Project Requirements

## Source

This document captures requirements extracted from the project PowerPoint presentation
(`Real-Time-Object-Detection-Using-Hardware-Accelerated-CNN-on-Xilinx-Zynq-FPGA_2.pptx`)
and identifies which requirements are taken directly from the PPT versus introduced as
implementation assumptions.

Legend:
- **[PPT]** — Taken directly from the presentation
- **[ASSUMED]** — Introduced during implementation; not explicitly stated in PPT
- **[DERIVED]** — Logically derived from PPT content

---

## 1. Platform & Device

| Requirement | Source |
|-------------|--------|
| Target board: Digilent ZedBoard | [PPT] Slide 1, Slide 9 |
| Target device: Xilinx Zynq-7000 XC7Z020 | [PPT] Slides 1, 2, 4, 9 |
| Dual-core ARM Cortex-A9 Processing System | [PPT] Slide 5 |
| 85K logic cells | [PPT] Slide 9 |
| DSP48E1 primitives for MAC operations | [PPT] Slides 4, 5 |
| BRAM_36 for weight/activation buffering | [PPT] Slides 4, 5 |
| DDR3 memory access | [DERIVED] ZedBoard has 512 MB DDR3 |
| AXI4-Lite for control registers | [PPT] Slide 5 |
| AXI-Stream for high-speed data transfer | [PPT] Slide 5 |
| AXI DMA / VDMA for DDR3 transfers | [PPT] Slide 5 |

---

## 2. CNN Architecture

| Requirement | Source |
|-------------|--------|
| Architecture: YOLOv5n or MobileNet-SSD | [PPT] Slides 4, 5 |
| Selected architecture: **YOLOv5n** | [ASSUMED] Preferred per PPT ordering; smaller |
| Input: camera or image frames | [PPT] Slides 2, 5 |
| Input dimensions: 320×320 or 416×416 | [ASSUMED] Standard YOLOv5n; confirmed 416×416 default |
| Output: bounding boxes + class labels + confidence | [DERIVED] Standard YOLO output |
| Classes: PASCAL VOC (20) or COCO (80) | [PPT] Slide 2 |

---

## 3. Performance Targets

| Requirement | Value | Source |
|-------------|-------|--------|
| Frame rate | ≥25 FPS | [PPT] Slides 2, 5, 9 |
| On-chip power | <10 W | [PPT] Slides 3, 9 |
| INT8 mAP accuracy drop budget | ≤2% vs FP32 baseline | [PPT] Slide 8 |
| Clock target | 100–200 MHz on PL | [DERIVED] From literature (Babu: 100 MHz, Huang: 200 MHz) |

---

## 4. Model Compression

| Requirement | Source |
|-------------|--------|
| INT8 quantization (Quantization-Aware Training) | [PPT] Slides 4, 5, 6 |
| Structured pruning | [PPT] Slides 4, 5 |
| Fit within XC7Z020 LUT, DSP48E1, BRAM_36 budget | [PPT] Slide 4 |

### XC7Z020 Resource Budget (from datasheet)
| Resource | Total | Target Utilization |
|----------|-------|--------------------|
| LUT | 53,200 | ≤80% (42,560) |
| LUTRAM | 17,400 | ≤50% (8,700) |
| FF | 106,400 | ≤80% (85,120) |
| BRAM_36 | 140 | ≤80% (112) |
| DSP48E1 | 220 | ≤90% (198) |

---

## 5. Hardware Accelerator

| Requirement | Source |
|-------------|--------|
| Pipelined convolution engine in Vivado HLS | [PPT] Slides 4, 5 |
| Loop unrolling and pipelining | [PPT] Slide 5 |
| AXI4-Lite control interface | [PPT] Slide 5 |
| AXI-Stream data interface | [PPT] Slide 5 |
| AXI DMA / VDMA for DDR transfers | [PPT] Slide 5 |

---

## 6. Camera & HDMI Interface

| Requirement | Source |
|-------------|--------|
| Camera interface via AXI-Stream/VDMA | [PPT] Slides 4, 5 |
| HDMI output for bounding-box overlay | [PPT] Slides 4, 5 |
| ZedBoard FMC / HDMI port | [PPT] Slide 4 |

> **Note:** Camera + HDMI integration requires the physical ZedBoard and
> specific camera module. This is deferred to hardware deployment phase.
> The software pipeline supports image file input and output as a substitute.

---

## 7. Benchmarking Requirements

| Metric | Source |
|--------|--------|
| Latency (ms/frame) | [PPT] Slide 4 |
| Throughput (FPS) | [PPT] Slides 2, 4 |
| mAP (COCO or VOC benchmark) | [PPT] Slides 2, 4 |
| On-chip power (W) — PS and PL separately | [PPT] Slides 4, 8 |
| Comparison against CPU/GPU baselines | [PPT] Slide 5 |

---

## 8. Software Pipeline Requirements

| Requirement | Source |
|-------------|--------|
| Image preprocessing: resize, normalize, format conversion | [PPT] Slide 5 |
| ARM software drivers for accelerator control | [PPT] Slide 5 |
| Bounding-box overlay | [PPT] Slide 5 |
| Postprocessing: decode + NMS | [DERIVED] Standard YOLO postprocessing |

---

## 9. Dataset

| Requirement | Source |
|-------------|--------|
| COCO 2017 dataset support | [PPT] Slides 2, 5, 6 |
| PASCAL VOC dataset support | [PPT] Slides 2, 8 |
| Training / fine-tuning in PyTorch | [PPT] Slide 5 |

---

## 10. Project Timeline (from PPT)

| Phase | Duration | Tasks |
|-------|----------|-------|
| Phase 1 (Month 1) | Weeks 1–2 | Literature survey + tool setup |
| Phase 1 (Month 1) | Weeks 3–4 | CNN model selection + training |
| Phase 2 (Month 2) | Weeks 5–6 | INT8 QAT + structured pruning |
| Phase 2 (Month 2) | Weeks 7–8 | HLS accelerator design |
| Phase 3 (Month 3) | Weeks 9–10 | HW-SW integration (AXI) |
| Phase 3 (Month 3) | Week 11 | Camera + HDMI pipeline |
| Phase 3 (Month 3) | Week 12 | Benchmarking + report |

---

## 11. Implementation Assumptions (not from PPT)

The following decisions were made during implementation and are not explicitly
stated in the PowerPoint:

1. **YOLOv5n selected** over MobileNet-SSD — smaller, better COCO mAP for the parameter count.
2. **Ultralytics library** used as the YOLOv5n framework — actively maintained, ONNX export built-in.
3. **Input resolution**: 416×416 (default YOLOv5n) — can be reduced to 320×320 for more FPS.
4. **Quantization method**: PyTorch Post-Training Quantization (PTQ) + Ultralytics QAT export.
5. **Bare-metal ARM software** selected as primary software target — simpler deployment, no OS.
6. **AXI DMA** (not VDMA) used for convolution data transfer — VDMA reserved for camera/display.
7. **Single convolution layer accelerator** implemented in HLS — demonstrates the architecture.
   Full network requires pipelining all layers (deferred to hardware integration phase).
8. **100 MHz PL clock target** selected as conservative baseline — matches published Zynq YOLOv4 results.
9. **COCO 2017 val2017** (5,000 images) used for accuracy validation — full train2017 for training.
10. **Structured pruning** is implemented as a post-training weight sparsification pass, not during training.
