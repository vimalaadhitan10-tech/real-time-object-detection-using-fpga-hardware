# ===========================================================================
# build.tcl
# Vivado Block Design and Implementation Script
# ZedBoard (XC7Z020CLG484-1) CNN Object Detection System
#
# Project: Real-Time CNN Object Detection
# Course:  BECE406E FPGA-Based System Design, VIT
#
# This script creates a complete Vivado project with:
#   - Zynq Processing System (PS7) configured for ZedBoard
#   - CNN Accelerator IP (from Vitis HLS export)
#   - AXI DMA for DDR transfers
#   - AXI Interconnect
#   - Clock and reset infrastructure
#   - Constraint file application
#
# Prerequisites:
#   - Vivado 2022.1 or 2022.2 installed
#   - HLS IP generated at: hls/proj_conv_engine/solution1/impl/ip/
#     (Run hls/scripts/run_hls.tcl first)
#   - ZedBoard board files installed in Vivado
#
# Usage (from project root directory):
#   vivado -mode batch -source fpga/scripts/build.tcl
#
# Or in Vivado Tcl Console:
#   source fpga/scripts/build.tcl
#
# Output:
#   fpga/build/zedboard_cnn/
#     └── zedboard_cnn.runs/impl_1/design_1_wrapper.bit  ← bitstream
#     └── zedboard_cnn.xsa                                ← hardware platform
# ===========================================================================

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
set SCRIPT_DIR    [file normalize [file dirname [info script]]]
set PROJECT_ROOT  [file normalize "$SCRIPT_DIR/../.."]
set BUILD_DIR     "$PROJECT_ROOT/fpga/build"
set PROJECT_NAME  "zedboard_cnn"
set TARGET_PART   "xc7z020clg484-1"
set BOARD_PART    "digilentinc.com:zedboard:part0:1.0"
set IP_REPO       "$PROJECT_ROOT/fpga/ip"
set HLS_IP_PATH   "$PROJECT_ROOT/hls/proj_conv_engine/solution1/impl/ip"
set XDC_FILE      "$PROJECT_ROOT/fpga/constraints/zedboard.xdc"
set DESIGN_NAME   "design_1"

puts "============================================================"
puts "  Vivado ZedBoard CNN Build Script"
puts "  Target: $TARGET_PART"
puts "  Build:  $BUILD_DIR/$PROJECT_NAME"
puts "============================================================"

# ---------------------------------------------------------------------------
# Create build directory
# ---------------------------------------------------------------------------
file mkdir $BUILD_DIR

# ---------------------------------------------------------------------------
# Create Vivado project
# ---------------------------------------------------------------------------
create_project $PROJECT_NAME "$BUILD_DIR/$PROJECT_NAME" \
    -part $TARGET_PART -force

# Set board (if ZedBoard board files are installed)
if {[catch {set_property board_part $BOARD_PART [current_project]}]} {
    puts "[WARNING] ZedBoard board files not found. Proceeding without board part."
    puts "  Install board files from: https://github.com/Digilent/vivado-boards"
}

set_property target_language Verilog [current_project]

# ---------------------------------------------------------------------------
# Add IP repositories
# ---------------------------------------------------------------------------
# Add the HLS-generated CNN IP
set ip_repos {}
if {[file exists $HLS_IP_PATH]} {
    lappend ip_repos $HLS_IP_PATH
    puts "[INFO] HLS IP found at: $HLS_IP_PATH"
} else {
    puts "[WARNING] HLS IP not found at: $HLS_IP_PATH"
    puts "  Run 'vitis_hls -f hls/scripts/run_hls.tcl' first."
    puts "  Continuing with block design (CNN IP will be missing)."
}

# Add any additional IPs from fpga/ip/
if {[file exists $IP_REPO]} {
    lappend ip_repos $IP_REPO
}

if {[llength $ip_repos] > 0} {
    set_property ip_repo_paths $ip_repos [current_project]
    update_ip_catalog
}

# ---------------------------------------------------------------------------
# Create Block Design
# ---------------------------------------------------------------------------
create_bd_design $DESIGN_NAME

# ---------------------------------------------------------------------------
# Add Zynq Processing System
# ---------------------------------------------------------------------------
puts "\n[Step 1] Adding Zynq Processing System..."
create_bd_cell -type ip -vlnv xilinx.com:ip:processing_system7:5.5 processing_system7_0

# Apply ZedBoard preset (provides correct PS configuration for ZedBoard)
# If board files are installed, use board preset:
catch {
    apply_bd_automation -rule xilinx.com:bd_rule:processing_system7 \
        -config {make_external "FIXED_IO, DDR" apply_board_preset "1" Master "Disable" Slave "Disable"} \
        [get_bd_cells processing_system7_0]
}

# Manual PS7 configuration for ZedBoard (fallback if board preset fails)
# DDR3: 512 MB, PL Clock: 100 MHz, Enable HP0/HP2 AXI ports, Enable FCLK_CLK0
set_property -dict [list \
    CONFIG.PCW_FPGA0_PERIPHERAL_FREQMHZ {100} \
    CONFIG.PCW_USE_S_AXI_HP0 {1} \
    CONFIG.PCW_USE_S_AXI_HP2 {1} \
    CONFIG.PCW_USE_M_AXI_GP0 {1} \
    CONFIG.PCW_USE_M_AXI_GP1 {1} \
    CONFIG.PCW_EN_CLK0_PORT {1} \
    CONFIG.PCW_EN_RST0_PORT {1} \
    CONFIG.PCW_UART0_PERIPHERAL_ENABLE {1} \
    CONFIG.PCW_UART0_UART0_IO {MIO 14 .. 15} \
    CONFIG.PCW_TTC0_PERIPHERAL_ENABLE {1} \
    CONFIG.PCW_USB0_PERIPHERAL_ENABLE {1} \
    CONFIG.PCW_SD0_PERIPHERAL_ENABLE {1} \
    CONFIG.PCW_MIO_14_SLEW {slow} \
    CONFIG.PCW_MIO_15_SLEW {slow} \
] [get_bd_cells processing_system7_0]

# ---------------------------------------------------------------------------
# Add AXI DMA
# ---------------------------------------------------------------------------
puts "\n[Step 2] Adding AXI DMA..."
create_bd_cell -type ip -vlnv xilinx.com:ip:axi_dma:7.1 axi_dma_0

set_property -dict [list \
    CONFIG.c_include_sg {0} \
    CONFIG.c_sg_include_stscntrl_strm {0} \
    CONFIG.c_m_axi_mm2s_data_width {64} \
    CONFIG.c_m_axis_mm2s_tdata_width {8} \
    CONFIG.c_m_axi_s2mm_data_width {64} \
    CONFIG.c_s_axis_s2mm_tdata_width {8} \
    CONFIG.c_mm2s_burst_size {256} \
    CONFIG.c_s2mm_burst_size {256} \
    CONFIG.c_addr_width {32} \
] [get_bd_cells axi_dma_0]

# ---------------------------------------------------------------------------
# Add CNN Accelerator IP (if available from HLS)
# ---------------------------------------------------------------------------
puts "\n[Step 3] Adding CNN Accelerator IP..."
set cnn_ip_available 0
if {[llength $ip_repos] > 0} {
    if {[catch {
        create_bd_cell -type ip \
            -vlnv VIT_BECE406E:cnn:conv_engine:1.0 conv_engine_0
        set cnn_ip_available 1
        puts "[INFO] CNN Accelerator IP added successfully."
    } err]} {
        puts "[WARNING] CNN IP not available: $err"
        puts "  Block design created without CNN IP."
        puts "  Run HLS synthesis first, then re-run this script."
    }
}

# ---------------------------------------------------------------------------
# Add AXI Interconnect (for control path GP0 master)
# ---------------------------------------------------------------------------
puts "\n[Step 4] Adding AXI Interconnect..."
set num_slaves 2
if {$cnn_ip_available} { set num_slaves 3 }

create_bd_cell -type ip -vlnv xilinx.com:ip:axi_interconnect:2.1 axi_interconnect_0
set_property -dict [list \
    CONFIG.NUM_MI $num_slaves \
] [get_bd_cells axi_interconnect_0]

# ---------------------------------------------------------------------------
# Add AXI SmartConnect (for HP port path to DMA memory)
# ---------------------------------------------------------------------------
create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect:1.0 smartconnect_0
set_property CONFIG.NUM_SI {2} [get_bd_cells smartconnect_0]

# ---------------------------------------------------------------------------
# Add Processor System Reset
# ---------------------------------------------------------------------------
create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset:5.0 rst_ps7_0_100M

# ---------------------------------------------------------------------------
# Clock and Reset Connections
# ---------------------------------------------------------------------------
puts "\n[Step 5] Connecting clocks and resets..."
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins rst_ps7_0_100M/slowest_sync_clk]
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins axi_dma_0/m_axi_mm2s_aclk]
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins axi_dma_0/m_axi_s2mm_aclk]
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins axi_dma_0/s_axi_lite_aclk]
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins axi_interconnect_0/ACLK]
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins smartconnect_0/aclk]

connect_bd_net [get_bd_pins processing_system7_0/FCLK_RESET0_N] \
    [get_bd_pins rst_ps7_0_100M/ext_reset_in]
connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] \
    [get_bd_pins axi_dma_0/axi_resetn]
connect_bd_net [get_bd_pins rst_ps7_0_100M/interconnect_aresetn] \
    [get_bd_pins axi_interconnect_0/ARESETN]

if {$cnn_ip_available} {
    connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
        [get_bd_pins conv_engine_0/ap_clk]
    connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] \
        [get_bd_pins conv_engine_0/ap_rst_n]
}

# ---------------------------------------------------------------------------
# AXI Control Path: PS GP0 → AXI IC → DMA + CNN (AXI4-Lite)
# ---------------------------------------------------------------------------
puts "\n[Step 6] Connecting AXI control path..."
connect_bd_intf_net [get_bd_intf_pins processing_system7_0/M_AXI_GP0] \
    [get_bd_intf_pins axi_interconnect_0/S00_AXI]

connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins axi_interconnect_0/S00_ACLK]
connect_bd_net [get_bd_pins rst_ps7_0_100M/interconnect_aresetn] \
    [get_bd_pins axi_interconnect_0/S00_ARESETN]

connect_bd_intf_net [get_bd_intf_pins axi_interconnect_0/M00_AXI] \
    [get_bd_intf_pins axi_dma_0/S_AXI_LITE]
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins axi_interconnect_0/M00_ACLK]
connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] \
    [get_bd_pins axi_interconnect_0/M00_ARESETN]

if {$cnn_ip_available} {
    connect_bd_intf_net [get_bd_intf_pins axi_interconnect_0/M01_AXI] \
        [get_bd_intf_pins conv_engine_0/s_axi_control]
    connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
        [get_bd_pins axi_interconnect_0/M01_ACLK]
    connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] \
        [get_bd_pins axi_interconnect_0/M01_ARESETN]
}

# ---------------------------------------------------------------------------
# AXI Data Path: DMA ↔ CNN ↔ HP0 (high-performance DDR port)
# ---------------------------------------------------------------------------
puts "\n[Step 7] Connecting AXI data path..."
if {$cnn_ip_available} {
    # DMA MM2S → CNN input stream
    connect_bd_intf_net [get_bd_intf_pins axi_dma_0/M_AXIS_MM2S] \
        [get_bd_intf_pins conv_engine_0/s_axis_input]
    # CNN output stream → DMA S2MM
    connect_bd_intf_net [get_bd_intf_pins conv_engine_0/s_axis_output] \
        [get_bd_intf_pins axi_dma_0/S_AXIS_S2MM]
}

# DMA memory interfaces → SmartConnect → HP0
connect_bd_intf_net [get_bd_intf_pins axi_dma_0/M_AXI_MM2S] \
    [get_bd_intf_pins smartconnect_0/S00_AXI]
connect_bd_intf_net [get_bd_intf_pins axi_dma_0/M_AXI_S2MM] \
    [get_bd_intf_pins smartconnect_0/S01_AXI]
connect_bd_intf_net [get_bd_intf_pins smartconnect_0/M00_AXI] \
    [get_bd_intf_pins processing_system7_0/S_AXI_HP0]

# HP0 clock
connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] \
    [get_bd_pins processing_system7_0/S_AXI_HP0_ACLK]

# ---------------------------------------------------------------------------
# Interrupt connections
# ---------------------------------------------------------------------------
puts "\n[Step 8] Connecting interrupts..."
create_bd_cell -type ip -vlnv xilinx.com:ip:xlconcat:2.1 xlconcat_0
set_property CONFIG.NUM_PORTS {2} [get_bd_cells xlconcat_0]

connect_bd_net [get_bd_pins axi_dma_0/mm2s_introut] \
    [get_bd_pins xlconcat_0/In0]
connect_bd_net [get_bd_pins axi_dma_0/s2mm_introut] \
    [get_bd_pins xlconcat_0/In1]
connect_bd_net [get_bd_pins xlconcat_0/dout] \
    [get_bd_pins processing_system7_0/IRQ_F2P]

# ---------------------------------------------------------------------------
# Address Assignment
# ---------------------------------------------------------------------------
puts "\n[Step 9] Assigning addresses..."
assign_bd_address

# Manual overrides for key addresses (adjust if conflicts occur)
catch {
    set_property offset 0x40400000 [get_bd_addr_segs \
        {processing_system7_0/Data/SEG_axi_dma_0_Reg}]
    set_property range 64K [get_bd_addr_segs \
        {processing_system7_0/Data/SEG_axi_dma_0_Reg}]
}

if {$cnn_ip_available} {
    catch {
        set_property offset 0x43C00000 [get_bd_addr_segs \
            {processing_system7_0/Data/SEG_conv_engine_0_Reg}]
        set_property range 64K [get_bd_addr_segs \
            {processing_system7_0/Data/SEG_conv_engine_0_Reg}]
    }
}

# ---------------------------------------------------------------------------
# Validate design
# ---------------------------------------------------------------------------
puts "\n[Step 10] Validating block design..."
if {[validate_bd_design]} {
    puts "[PASS] Block design validation passed."
} else {
    puts "[WARNING] Block design validation reported issues. Review in GUI."
}

save_bd_design

# ---------------------------------------------------------------------------
# Generate HDL wrapper
# ---------------------------------------------------------------------------
puts "\n[Step 11] Generating HDL wrapper..."
make_wrapper -files [get_files ${DESIGN_NAME}.bd] -top
add_files -norecurse "$BUILD_DIR/$PROJECT_NAME/${PROJECT_NAME}.srcs/sources_1/bd/${DESIGN_NAME}/hdl/${DESIGN_NAME}_wrapper.v"
set_property top ${DESIGN_NAME}_wrapper [current_fileset]

# ---------------------------------------------------------------------------
# Add constraints
# ---------------------------------------------------------------------------
if {[file exists $XDC_FILE]} {
    puts "\n[Step 12] Adding constraints..."
    add_files -fileset constrs_1 $XDC_FILE
} else {
    puts "[WARNING] XDC file not found at $XDC_FILE"
}

# ---------------------------------------------------------------------------
# Synthesis
# ---------------------------------------------------------------------------
puts "\n[Step 13] Running synthesis..."
launch_runs synth_1 -jobs 4
wait_on_run synth_1

if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {
    puts "[ERROR] Synthesis FAILED. Check logs in:"
    puts "  $BUILD_DIR/$PROJECT_NAME/$PROJECT_NAME.runs/synth_1/"
    exit 1
}
puts "[PASS] Synthesis complete."

# ---------------------------------------------------------------------------
# Implementation
# ---------------------------------------------------------------------------
puts "\n[Step 14] Running implementation..."
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1

if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {
    puts "[ERROR] Implementation FAILED. Check logs in:"
    puts "  $BUILD_DIR/$PROJECT_NAME/$PROJECT_NAME.runs/impl_1/"
    exit 1
}
puts "[PASS] Implementation and bitstream generation complete."

# Report timing
open_run impl_1
report_timing_summary -file "$BUILD_DIR/timing_summary.rpt"
report_utilization -file "$BUILD_DIR/utilization_report.rpt"
report_power -file "$BUILD_DIR/power_report.rpt"

# ---------------------------------------------------------------------------
# Export hardware platform (XSA)
# ---------------------------------------------------------------------------
puts "\n[Step 15] Exporting hardware platform (XSA)..."
write_hw_platform -fixed -include_bit \
    -file "$BUILD_DIR/$PROJECT_NAME.xsa"
puts "[INFO] Hardware platform exported: $BUILD_DIR/$PROJECT_NAME.xsa"

puts "\n============================================================"
puts "  Build COMPLETE"
puts "  Bitstream:        $BUILD_DIR/$PROJECT_NAME/$PROJECT_NAME.runs/impl_1/design_1_wrapper.bit"
puts "  Hardware platform: $BUILD_DIR/$PROJECT_NAME.xsa"
puts "  Reports:"
puts "    Timing:       $BUILD_DIR/timing_summary.rpt"
puts "    Utilization:  $BUILD_DIR/utilization_report.rpt"
puts "    Power:        $BUILD_DIR/power_report.rpt"
puts "============================================================"

close_project
exit 0
