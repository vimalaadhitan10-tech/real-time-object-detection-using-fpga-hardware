# ===========================================================================
# run_hls.tcl
# Vitis HLS Build Script — Convolution Engine for ZedBoard XC7Z020
#
# Project: Real-Time CNN Object Detection
# Course:  BECE406E FPGA-Based System Design, VIT
#
# This script:
#   1. Creates the Vitis HLS project
#   2. Adds source and testbench files
#   3. Sets target device (XC7Z020) and clock (10 ns = 100 MHz)
#   4. Runs C simulation (csim_design)
#   5. Runs C synthesis  (csynth_design)
#   6. Optionally runs RTL co-simulation and IP export
#
# Usage:
#   vitis_hls -f hls/scripts/run_hls.tcl
#
# Or interactively in Vitis HLS GUI:
#   File → Open Project → (run this script first to create it)
#
# Prerequisites:
#   - Vitis HLS 2022.1 or 2022.2 installed
#   - Working directory: project root (not hls/)
#
# Output:
#   hls/proj_conv_engine/solution1/syn/report/  ← Resource utilization reports
#   hls/proj_conv_engine/solution1/impl/ip/     ← Packaged IP (after export)
# ===========================================================================

# ---------------------------------------------------------------------------
# Configuration — change paths if needed
# ---------------------------------------------------------------------------
set PROJECT_ROOT   [file normalize [file dirname [file dirname [info script]]]]
set PROJECT_NAME   "proj_conv_engine"
set SOLUTION_NAME  "solution1"
set TOP_FUNCTION   "conv_engine"
set TARGET_PART    "xc7z020clg484-1"   ;# ZedBoard XC7Z020CLG484-1
set CLOCK_PERIOD   "10"                ;# 10 ns = 100 MHz

set SRC_DIR        "$PROJECT_ROOT/src"
set TB_DIR         "$PROJECT_ROOT/testbench"
set OUTPUT_DIR     "$PROJECT_ROOT/$PROJECT_NAME"

# ---------------------------------------------------------------------------
# Create project
# ---------------------------------------------------------------------------
puts "============================================================"
puts "  Creating Vitis HLS Project: $PROJECT_NAME"
puts "  Target: $TARGET_PART @ ${CLOCK_PERIOD}ns"
puts "============================================================"

open_project $PROJECT_NAME

# Set top-level function
set_top $TOP_FUNCTION

# ---------------------------------------------------------------------------
# Add source files
# ---------------------------------------------------------------------------
add_files "$SRC_DIR/conv_engine.cpp" -cflags "-std=c++14"
add_files "$SRC_DIR/conv_engine.h"   -cflags "-std=c++14"

# ---------------------------------------------------------------------------
# Add testbench files
# ---------------------------------------------------------------------------
add_files -tb "$TB_DIR/tb_conv_engine.cpp" \
    -cflags "-std=c++14 -D__HLS_SIM__"

# ---------------------------------------------------------------------------
# Create and configure solution
# ---------------------------------------------------------------------------
open_solution $SOLUTION_NAME -flow_target vivado

# Set target FPGA part (XC7Z020 on ZedBoard)
set_part $TARGET_PART

# Set clock constraint (100 MHz target)
create_clock -period $CLOCK_PERIOD -name default

# ---------------------------------------------------------------------------
# Optimization directives (applied to top-level function)
# Note: Most directives are already embedded as #pragma HLS in the source.
# Add project-level overrides here if needed.
# ---------------------------------------------------------------------------
# config_compile -pipeline_loops 64
config_array_partition -throughput_driven off

# ---------------------------------------------------------------------------
# Stage 1: C Simulation
# ---------------------------------------------------------------------------
puts "\n[Stage 1] Running C Simulation..."
catch {
    csim_design -clean -O
} csim_result

if {$csim_result == 0} {
    puts "[PASS] C Simulation completed successfully"
} else {
    puts "[WARNING] C Simulation returned: $csim_result"
    puts "  Check hls/$PROJECT_NAME/$SOLUTION_NAME/csim/report/ for details"
}

# ---------------------------------------------------------------------------
# Stage 2: C Synthesis (HLS)
# ---------------------------------------------------------------------------
puts "\n[Stage 2] Running C Synthesis (HLS)..."
csynth_design

puts "\n[INFO] Synthesis complete."
puts "  Resource report: hls/$PROJECT_NAME/$SOLUTION_NAME/syn/report/"
puts "  Timing report:   hls/$PROJECT_NAME/$SOLUTION_NAME/syn/report/${TOP_FUNCTION}_csynth.rpt"

# ---------------------------------------------------------------------------
# Stage 3: RTL Co-simulation (optional — takes longer)
# Uncomment to run RTL co-simulation after synthesis
# ---------------------------------------------------------------------------
# puts "\n[Stage 3] Running RTL Co-simulation (Verilog)..."
# cosim_design -O -rtl verilog

# ---------------------------------------------------------------------------
# Stage 4: Export IP (packaged for use in Vivado block design)
# ---------------------------------------------------------------------------
puts "\n[Stage 4] Exporting IP Core..."
export_design -format ip_catalog \
    -description "CNN Convolution Engine for ZedBoard XC7Z020" \
    -display_name "conv_engine" \
    -version "1.0" \
    -vendor "VIT_BECE406E" \
    -library "cnn"

puts "\n============================================================"
puts "  Build Complete"
puts "  IP exported to: hls/$PROJECT_NAME/$SOLUTION_NAME/impl/ip/"
puts "  Copy this IP to: fpga/ip/ for Vivado integration"
puts "============================================================"

# Close project
close_project
exit 0
