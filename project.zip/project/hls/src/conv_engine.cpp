// ===========================================================================
// conv_engine.cpp
// Pipelined INT8 Convolution Engine — Synthesizable HLS Implementation
//
// Project: Real-Time CNN Object Detection on ZedBoard (XC7Z020)
// Course:  BECE406E FPGA-Based System Design, VIT
//
// Design Notes:
//   1. Input is received as a flat INT8 AXI-Stream: H×W×C pixels, CHW order.
//   2. A line buffer stores K-1 rows to form the sliding window.
//   3. The PE×SIMD compute array maps to DSP48E1 multipliers in Vivado.
//   4. The output is requantized to INT8 and emitted as AXI-Stream.
//   5. Loop structure: outer=output channels (tiled by PE),
//                      inner=spatial position (pipelined), innermost=kernel.
//
// Synthesis pragmas placed for Vitis HLS 2022.x.
// C simulation is self-contained and does not require HLS toolchain.
//
// ===========================================================================

#include "conv_engine.h"
#include <algorithm>  // std::max, std::min

// ---------------------------------------------------------------------------
// Requantization helper
// Converts INT32 accumulator to INT8 using scale/shift/zero-point.
// This models the integer-arithmetic requantization used in INT8 inference.
// ---------------------------------------------------------------------------
inline out8_t requantize(acc32_t acc, int scale, int shift, int zero_point)
{
    // Multiply by scale (Q0.31 fixed-point) then right-shift
    // In hardware this is a 32×32→64 multiply — but we use
    // a simplified version here that fits in 32 bits for simulation.
    // For synthesis: HLS will infer DSP48E1 for the multiply.
    acc32_t scaled = (acc * (acc32_t)scale) >> shift;
    scaled += (acc32_t)zero_point;

    // Saturate to INT8 range [-128, 127]
    if (scaled > 127)  scaled = 127;
    if (scaled < -128) scaled = -128;

    return (out8_t)scaled;
}

// ---------------------------------------------------------------------------
// Output dimension helper
// ---------------------------------------------------------------------------
inline int out_dim(int in_dim, int k, int stride, int pad)
{
    return (in_dim + 2 * pad - k) / stride + 1;
}

// ---------------------------------------------------------------------------
// Reference convolution (C++ model — used by testbench)
// Plain, non-optimized implementation for correctness reference.
// Not synthesized (no HLS pragmas).
// ---------------------------------------------------------------------------
void conv_reference(
    const data8_t input  [MAX_IN_H][MAX_IN_W][MAX_IN_C],
    const data8_t weights[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K],
    const acc32_t bias   [MAX_OUT_C],
    out8_t        output [MAX_IN_H][MAX_IN_W][MAX_OUT_C],
    const ConvConfig &cfg)
{
    int out_h = out_dim(cfg.in_h, cfg.k, cfg.stride, cfg.pad);
    int out_w = out_dim(cfg.in_w, cfg.k, cfg.stride, cfg.pad);

    for (int oc = 0; oc < cfg.out_c; oc++) {
        for (int oh = 0; oh < out_h; oh++) {
            for (int ow = 0; ow < out_w; ow++) {
                acc32_t acc = bias[oc];
                for (int ic = 0; ic < cfg.in_c; ic++) {
                    for (int kh = 0; kh < cfg.k; kh++) {
                        for (int kw = 0; kw < cfg.k; kw++) {
                            int ih = oh * cfg.stride - cfg.pad + kh;
                            int iw = ow * cfg.stride - cfg.pad + kw;
                            data8_t pixel = 0;
                            if (ih >= 0 && ih < cfg.in_h && iw >= 0 && iw < cfg.in_w) {
                                pixel = input[ih][iw][ic];
                            }
                            acc += (acc32_t)pixel * (acc32_t)weights[oc][ic][kh][kw];
                        }
                    }
                }
                output[oh][ow][oc] = requantize(acc, cfg.act_scale, cfg.act_shift, cfg.act_zero);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Synthesizable HLS convolution engine
// ---------------------------------------------------------------------------
//
// Interface strategy:
//   - AXI4-Stream for pixel I/O (maps to DMA or direct VDMA connection)
//   - BRAM interfaces for weights and bias (read-only during inference)
//   - AXI4-Lite for cfg struct members (HLS generates AXI-Lite slave automatically)
//   - ap_ctrl_hs for start/done/idle handshake
//
// Memory layout of input stream: CHW order
//   Pixel order: channel 0 of pixel (0,0), channel 1 of pixel (0,0), ...,
//                channel C-1 of pixel (0,0), channel 0 of pixel (0,1), ...
//                (i.e., inner dimension = channel)
//
// Output stream: same CHW layout for output feature map.
//

void conv_engine(
    hls::stream<axis8_t>    &s_axis_input,
    hls::stream<axis8_t>    &s_axis_output,
    const data8_t            weights[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K],
    const acc32_t            bias[MAX_OUT_C],
    const ConvConfig        &cfg)
{
    // -----------------------------------------------------------------------
    // HLS Interface directives
    // -----------------------------------------------------------------------
#pragma HLS INTERFACE axis         port=s_axis_input   name=s_axis_input
#pragma HLS INTERFACE axis         port=s_axis_output  name=s_axis_output
#pragma HLS INTERFACE bram         port=weights
#pragma HLS INTERFACE bram         port=bias
#pragma HLS INTERFACE s_axilite    port=cfg            bundle=control
#pragma HLS INTERFACE s_axilite    port=return         bundle=control

    // -----------------------------------------------------------------------
    // Array partitioning for weight access parallelism
    // Partition the output-channel dimension by PE factor
    // Partition the input-channel dimension by SIMD factor
    // -----------------------------------------------------------------------
#pragma HLS ARRAY_PARTITION variable=weights dim=1 factor=PE   cyclic
#pragma HLS ARRAY_PARTITION variable=weights dim=2 factor=SIMD cyclic
#pragma HLS ARRAY_PARTITION variable=bias    dim=1 factor=PE   cyclic

    // -----------------------------------------------------------------------
    // Local line buffer: stores K-1 complete rows to form sliding window
    // Size: (K-1) × MAX_IN_W × MAX_IN_C — stored in BRAM
    // -----------------------------------------------------------------------
    static data8_t line_buf[MAX_K - 1][MAX_IN_W][MAX_IN_C];
#pragma HLS ARRAY_PARTITION variable=line_buf dim=1 complete  // K-1 rows: fully partition (K=3 → 2 BRAMs)
#pragma HLS ARRAY_PARTITION variable=line_buf dim=3 factor=SIMD cyclic

    // Window buffer: K×K×C current computation window
    data8_t window[MAX_K][MAX_K][MAX_IN_C];
#pragma HLS ARRAY_PARTITION variable=window dim=1 complete
#pragma HLS ARRAY_PARTITION variable=window dim=2 complete
#pragma HLS ARRAY_PARTITION variable=window dim=3 factor=SIMD cyclic

    // Accumulator for PE output channels
    acc32_t acc[PE];
#pragma HLS ARRAY_PARTITION variable=acc dim=1 complete

    // -----------------------------------------------------------------------
    // Derived dimensions
    // -----------------------------------------------------------------------
    int out_h = out_dim(cfg.in_h, cfg.k, cfg.stride, cfg.pad);
    int out_w = out_dim(cfg.in_w, cfg.k, cfg.stride, cfg.pad);

    // -----------------------------------------------------------------------
    // Step 1: Read entire input feature map from AXI-Stream into local buffer
    // For the full accelerator, this would be streamed row-by-row using
    // the line buffer. For clarity in this implementation, we first buffer
    // the complete input (feasible for 56×56×64 = 200 KB with DRAM ping-pong).
    // A future optimization replaces this with true streaming line-buffer logic.
    // -----------------------------------------------------------------------
    static data8_t in_buf[MAX_IN_H][MAX_IN_W][MAX_IN_C];
#pragma HLS ARRAY_PARTITION variable=in_buf dim=3 factor=SIMD cyclic

    READ_INPUT:
    for (int ih = 0; ih < cfg.in_h; ih++) {
        for (int iw = 0; iw < cfg.in_w; iw++) {
            for (int ic = 0; ic < cfg.in_c; ic++) {
#pragma HLS PIPELINE II=1
                axis8_t pkt = s_axis_input.read();
                in_buf[ih][iw][ic] = (data8_t)pkt.data;
            }
        }
    }

    // -----------------------------------------------------------------------
    // Step 2: Compute convolution — output channel tiled by PE
    // -----------------------------------------------------------------------
    OC_TILE:
    for (int oc_base = 0; oc_base < cfg.out_c; oc_base += PE) {
        // Output spatial loop — pipelined at inner level
        OUT_H:
        for (int oh = 0; oh < out_h; oh++) {
            OUT_W:
            for (int ow = 0; ow < out_w; ow++) {
                // Initialize accumulators for this PE group
                INIT_ACC:
                for (int pe = 0; pe < PE; pe++) {
#pragma HLS UNROLL
                    int oc = oc_base + pe;
                    acc[pe] = (oc < cfg.out_c) ? bias[oc] : (acc32_t)0;
                }

                // Convolution: spatial kernel × input channels
                KH:
                for (int kh = 0; kh < cfg.k; kh++) {
                    KW:
                    for (int kw = 0; kw < cfg.k; kw++) {
                        IC_SIMD:
                        for (int ic = 0; ic < cfg.in_c; ic += SIMD) {
#pragma HLS PIPELINE II=1
                            // Compute input pixel address with padding
                            int ih = oh * cfg.stride - cfg.pad + kh;
                            int iw = ow * cfg.stride - cfg.pad + kw;

                            // Fetch SIMD input values (0 if in padding region)
                            data8_t in_val[SIMD];
#pragma HLS ARRAY_PARTITION variable=in_val complete
                            for (int s = 0; s < SIMD; s++) {
#pragma HLS UNROLL
                                int c = ic + s;
                                if (ih >= 0 && ih < cfg.in_h &&
                                    iw >= 0 && iw < cfg.in_w &&
                                    c  < cfg.in_c) {
                                    in_val[s] = in_buf[ih][iw][c];
                                } else {
                                    in_val[s] = (data8_t)0;
                                }
                            }

                            // Accumulate PE × SIMD MACs
                            // HLS maps each INT8×INT8→INT32 to a DSP48E1
                            PE_LOOP:
                            for (int pe = 0; pe < PE; pe++) {
#pragma HLS UNROLL
                                int oc = oc_base + pe;
                                if (oc < cfg.out_c) {
                                    SIMD_LOOP:
                                    for (int s = 0; s < SIMD; s++) {
#pragma HLS UNROLL
                                        int c = ic + s;
                                        if (c < cfg.in_c) {
                                            acc[pe] += (acc32_t)in_val[s] *
                                                       (acc32_t)weights[oc][c][kh][kw];
                                        }
                                    }
                                }
                            }
                        } // IC_SIMD
                    } // KW
                } // KH

                // Write PE output values to AXI-Stream
                WRITE_OUTPUT:
                for (int pe = 0; pe < PE; pe++) {
#pragma HLS PIPELINE II=1
                    int oc = oc_base + pe;
                    if (oc < cfg.out_c) {
                        out8_t out_val = requantize(acc[pe],
                                                    cfg.act_scale,
                                                    cfg.act_shift,
                                                    cfg.act_zero);
                        axis8_t pkt;
                        pkt.data = (ap_uint<8>)(uint8_t)(int8_t)out_val;
                        // Set TLAST on last output element
                        bool last = (oc == cfg.out_c - 1) &&
                                    (oh == out_h - 1) &&
                                    (ow == out_w - 1);
                        pkt.last = last ? 1 : 0;
                        pkt.keep = 0xFF;
                        pkt.strb = 0xFF;
                        s_axis_output.write(pkt);
                    }
                }

            } // OUT_W
        } // OUT_H
    } // OC_TILE
}
