// ===========================================================================
// conv_engine.h
// Pipelined INT8 Convolution Engine for Xilinx Zynq-7000 XC7Z020
//
// Project: Real-Time CNN Object Detection on ZedBoard
// Course:  BECE406E FPGA-Based System Design, VIT
//
// Architecture:
//   - AXI4-Stream input/output for pixel data
//   - AXI4-Lite control (implemented via ap_ctrl_hs in HLS)
//   - INT8 arithmetic mapped to DSP48E1 primitives
//   - BRAM_36 weight and line-buffer storage
//   - Configurable: kernel size, stride, padding, channels
//
// Resource targets (XC7Z020):
//   DSP48E1: up to 198/220 (90%)
//   BRAM_36:  up to 112/140 (80%)
//
// ===========================================================================

#ifndef CONV_ENGINE_H
#define CONV_ENGINE_H

#include "ap_int.h"
#include "ap_fixed.h"
#include "hls_stream.h"
#include "ap_axi_sdata.h"

// ---------------------------------------------------------------------------
// Compile-time configuration
// Adjust these to trade off resource utilization vs. layer support.
// ---------------------------------------------------------------------------

// Maximum supported dimensions
#define MAX_IN_H     56   // Max input height (pixels)
#define MAX_IN_W     56   // Max input width  (pixels)
#define MAX_IN_C     64   // Max input channels
#define MAX_OUT_C    64   // Max output channels
#define MAX_K        3    // Max kernel size (3×3)

// Parallelism factors — tune for XC7Z020 DSP budget
// PE = number of output channels computed in parallel
// SIMD = number of input channels multiplied in parallel per PE
#define PE           8    // Parallel output channels (8 × 8 = 64 DSPs active)
#define SIMD         8    // Parallel input channel MACs per PE

// Numeric precision
// INT8 inputs/weights, INT32 accumulation, INT8 output after requantization
typedef ap_int<8>   data8_t;    // Input activations and weights
typedef ap_int<32>  acc32_t;    // Accumulator (prevents overflow)
typedef ap_int<8>   out8_t;     // Output activations (after requantize)

// AXI-Stream pixel type: 8-bit data + TLAST
typedef ap_axiu<8, 0, 0, 0>    axis8_t;

// ---------------------------------------------------------------------------
// Convolution layer configuration (passed via AXI4-Lite)
// ---------------------------------------------------------------------------
struct ConvConfig {
    int in_h;       // Input height
    int in_w;       // Input width
    int in_c;       // Input channels
    int out_c;      // Output channels
    int k;          // Kernel size (k×k, square)
    int stride;     // Convolution stride
    int pad;        // Zero-padding (pixels on each side)
    int act_scale;  // Output requantization scale (Q0.31 fixed-point multiplier)
    int act_shift;  // Output requantization right shift
    int act_zero;   // Output zero-point (added after scale+shift)
};

// ---------------------------------------------------------------------------
// Top-level HLS function declaration
// ---------------------------------------------------------------------------
//
// Interface directives (applied in conv_engine.cpp):
//   s_axis_input  → AXI4-Stream slave  (pixel data in, 8 bits/transfer)
//   s_axis_output → AXI4-Stream master (feature map out, 8 bits/transfer)
//   weights       → ap_memory (BRAM_36 inferred by HLS array pragma)
//   bias          → ap_memory (BRAM_36)
//   cfg           → AXI4-Lite slave
//   return        → ap_ctrl_hs (start/done/idle via AXI4-Lite)
//
void conv_engine(
    hls::stream<axis8_t>    &s_axis_input,          // Input feature map stream
    hls::stream<axis8_t>    &s_axis_output,         // Output feature map stream
    const data8_t            weights[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K],
    const acc32_t            bias[MAX_OUT_C],
    const ConvConfig        &cfg
);

// ---------------------------------------------------------------------------
// Helper functions (also used by testbench reference model)
// ---------------------------------------------------------------------------

// Reference (pure C++) convolution — used in testbench for numerical comparison
void conv_reference(
    const data8_t input [MAX_IN_H][MAX_IN_W][MAX_IN_C],
    const data8_t weights[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K],
    const acc32_t bias   [MAX_OUT_C],
    out8_t        output [MAX_IN_H][MAX_IN_W][MAX_OUT_C],
    const ConvConfig &cfg
);

// Requantize INT32 accumulator to INT8
inline out8_t requantize(acc32_t acc, int scale, int shift, int zero_point);

// Compute output spatial dimension
inline int out_dim(int in_dim, int k, int stride, int pad);

#endif // CONV_ENGINE_H
