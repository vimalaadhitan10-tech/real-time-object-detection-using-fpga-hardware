#!/usr/bin/env python3
"""
ref_conv.py — Python reference model for HLS convolution engine verification.

This script provides:
1. A pure NumPy INT8 convolution reference implementation
2. A comparison against the HLS C simulation testbench results
3. Weight file generation for the testbench

Usage:
    python hls/testbench/ref_conv.py

This runs the same test cases as tb_conv_engine.cpp using NumPy and reports
whether the expected outputs match documented test case expectations.
"""

import numpy as np
import struct
import os

# ============================================================================
# Reference convolution (mirrors conv_reference in conv_engine.cpp)
# ============================================================================

def requantize_int8(acc: np.ndarray, scale: int, shift: int, zero: int) -> np.ndarray:
    """
    Mirrors requantize() in conv_engine.cpp:
      scaled = (acc * scale) >> shift
      clamped to [-128, 127]
    """
    scaled = (acc.astype(np.int64) * scale) >> shift
    scaled += zero
    return np.clip(scaled, -128, 127).astype(np.int8)


def conv_reference_nhwc(
    inp: np.ndarray,       # [H, W, C_in]  int8
    weights: np.ndarray,   # [C_out, C_in, K, K]  int8
    bias: np.ndarray,      # [C_out]  int32
    k: int,
    stride: int,
    pad: int,
    scale: int,
    shift: int,
    zero: int
) -> np.ndarray:
    """
    Reference convolution. Returns [H_out, W_out, C_out] int8 array.
    Matches conv_reference() in conv_engine.cpp exactly.
    """
    H, W, C_in = inp.shape
    C_out = weights.shape[0]

    H_out = (H + 2 * pad - k) // stride + 1
    W_out = (W + 2 * pad - k) // stride + 1

    # Pad input
    if pad > 0:
        inp_padded = np.pad(inp, [(pad, pad), (pad, pad), (0, 0)],
                            mode='constant', constant_values=0)
    else:
        inp_padded = inp

    out = np.zeros((H_out, W_out, C_out), dtype=np.int32)

    for oc in range(C_out):
        for oh in range(H_out):
            for ow in range(W_out):
                acc = int(bias[oc])
                for ic in range(C_in):
                    for kh in range(k):
                        for kw in range(k):
                            ih = oh * stride + kh
                            iw = ow * stride + kw
                            acc += int(inp_padded[ih, iw, ic]) * int(weights[oc, ic, kh, kw])
                out[oh, ow, oc] = acc

    return requantize_int8(out, scale, shift, zero)


# ============================================================================
# Test cases (mirror tb_conv_engine.cpp)
# ============================================================================

def make_inputs(in_h, in_w, in_c, out_c, k, seed_data=42, seed_w=77, seed_b=33):
    rng_d = np.random.RandomState(seed_data)
    rng_w = np.random.RandomState(seed_w)
    rng_b = np.random.RandomState(seed_b)

    inp     = rng_d.randint(-25, 26, (in_h, in_w, in_c), dtype=np.int8)
    weights = rng_w.randint(-25, 26, (out_c, in_c, k, k), dtype=np.int8)
    bias    = rng_b.randint(-100, 101, (out_c,), dtype=np.int32)
    return inp, weights, bias


def run_test(name, in_h, in_w, in_c, out_c, k, stride, pad, scale, shift, zero,
             seed_d=42, seed_w=77, seed_b=33):
    print(f"\n=== TEST: {name} ===")
    print(f"  Config: in={in_h}×{in_w}×{in_c}  out_c={out_c}  k={k}  stride={stride}  pad={pad}")

    inp, weights, bias = make_inputs(in_h, in_w, in_c, out_c, k, seed_d, seed_w, seed_b)
    out = conv_reference_nhwc(inp, weights, bias, k, stride, pad, scale, shift, zero)

    H_out = (in_h + 2*pad - k) // stride + 1
    W_out = (in_w + 2*pad - k) // stride + 1
    total = H_out * W_out * out_c

    print(f"  Output shape: {H_out}×{W_out}×{out_c} = {total} elements")
    print(f"  Output range: [{out.min()}, {out.max()}]")
    print(f"  Output mean:  {out.mean():.2f}")
    print(f"  [INFO] Reference output computed — use to validate HLS testbench")
    return out


def test_zero_weights():
    print("\n=== TEST: Zero Weights (bias-only) ===")
    inp     = np.zeros((4, 4, 2), dtype=np.int8)  # input doesn't matter
    weights = np.zeros((2, 2, 3, 3), dtype=np.int8)
    bias    = np.array([10, -5], dtype=np.int32)

    # Fill random input (doesn't affect result since weights=0)
    rng = np.random.RandomState(123)
    inp = rng.randint(-25, 26, (4, 4, 2), dtype=np.int8)

    out = conv_reference_nhwc(inp, weights, bias, k=3, stride=1, pad=1,
                               scale=1, shift=0, zero=0)

    expected_ch0 = np.clip(10, -128, 127)
    expected_ch1 = np.clip(-5, -128, 127)

    match = (np.all(out[:, :, 0] == expected_ch0) and
             np.all(out[:, :, 1] == expected_ch1))
    print(f"  Expected: ch0={expected_ch0}, ch1={expected_ch1}")
    print(f"  Got: ch0={out[0,0,0]}, ch1={out[0,0,1]}")
    print(f"  {'[PASS]' if match else '[FAIL]'} Zero-weight test")
    return match


def test_saturation():
    print("\n=== TEST: Saturation / Overflow ===")
    # 3×3 input, all 127; 3×3 weight, all 1; stride=1, pad=0
    # acc = 127 * 9 = 1143 → requantize(1143, 1, 0, 0) → clip(1143, -128, 127) = 127
    inp     = np.full((3, 3, 1), 127, dtype=np.int8)
    weights = np.ones((1, 1, 3, 3), dtype=np.int8)
    bias    = np.zeros(1, dtype=np.int32)

    out = conv_reference_nhwc(inp, weights, bias, k=3, stride=1, pad=0,
                               scale=1, shift=0, zero=0)

    print(f"  Input=127×9, weight=1×9: acc=1143, expected saturated=127")
    print(f"  Got: {out[0, 0, 0]}")
    ok = (int(out[0, 0, 0]) == 127)
    print(f"  {'[PASS]' if ok else '[FAIL]'} Saturation test")
    return ok


def main():
    print("=" * 60)
    print("  Python Reference Conv Model")
    print("  Mirrors tb_conv_engine.cpp test cases")
    print("  ZedBoard XC7Z020 Project, BECE406E VIT")
    print("=" * 60)

    run_test("3x3 Conv 1ch→1ch (baseline)",    5, 5, 1, 1, 3, 1, 0, 1, 0, 0)
    run_test("3x3 Conv 4ch→4ch",               5, 5, 4, 4, 3, 1, 0, 1, 0, 0)
    run_test("3x3 Conv stride=2",              8, 8, 4, 4, 3, 2, 0, 1, 0, 0, 55, 66)
    run_test("3x3 Conv pad=1 (same padding)",  6, 6, 4, 4, 3, 1, 1, 1, 0, 0, 11, 22)
    run_test("1x1 Pointwise Conv",             8, 8, 8, 8, 1, 1, 0, 1, 0, 0, 33, 44)
    run_test("3x3 Conv 8ch→8ch larger",        14,14, 8, 8, 3, 1, 1, 1, 0, 0, 77, 88)
    run_test("3x3 Conv stride=2 pad=1",        8, 8, 4, 4, 3, 2, 1, 1, 0, 0, 99, 100)

    zw = test_zero_weights()
    sat = test_saturation()

    print("\n" + "=" * 60)
    print("  Python reference model complete.")
    print("  Use these results to validate HLS C-sim output.")
    print("=" * 60)


if __name__ == "__main__":
    main()
