// ===========================================================================
// tb_conv_engine.cpp
// C Simulation Testbench for conv_engine HLS accelerator
//
// Project: Real-Time CNN Object Detection on ZedBoard (XC7Z020)
// Course:  BECE406E FPGA-Based System Design, VIT
//
// Tests:
//   1. 3×3 convolution, 1 input channel, 1 output channel (baseline)
//   2. 3×3 convolution, 4 input channels, 4 output channels
//   3. 3×3 convolution with stride=2 (downsampling)
//   4. 3×3 convolution with padding (same padding)
//   5. 1×1 convolution (pointwise)
//   6. Overflow / saturation boundary test
//   7. Zero-weight test (output should equal bias after requantization)
//
// Verification:
//   - HLS accelerator output is compared pixel-by-pixel to conv_reference()
//   - Tolerance: exact match (integer arithmetic, no floating-point error)
//   - Mismatch triggers test failure with diagnostic output
//
// Run via Vitis HLS Tcl:
//   vitis_hls -f hls/scripts/run_hls.tcl
//
// Run standalone (no HLS tools needed) — compile with g++ or cl.exe:
//   Windows: cl /std:c++17 /I<HLS_INCLUDE> tb_conv_engine.cpp conv_engine.cpp
//   Linux:   g++ -std=c++17 -I<HLS_INCLUDE> tb_conv_engine.cpp conv_engine.cpp -o tb
//
// Note: When compiled standalone (not under Vitis HLS), replace HLS headers
//       with stub implementations. The tb_stubs.h file provides these stubs.
//
// ===========================================================================

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cassert>

// Include HLS headers — these come from Vitis HLS installation.
// When compiling standalone, provide stubs (see tb_stubs.h).
#ifdef __HLS_SIM__
  #include "conv_engine.h"
#else
  #include "tb_stubs.h"
  #include "conv_engine.h"
#endif

// ---------------------------------------------------------------------------
// Test result tracking
// ---------------------------------------------------------------------------
static int total_tests  = 0;
static int passed_tests = 0;
static int failed_tests = 0;

// ---------------------------------------------------------------------------
// Helper: fill array with deterministic pseudo-random INT8 values
// ---------------------------------------------------------------------------
static void fill_random_int8(data8_t *arr, int n, int seed = 42)
{
    srand(seed);
    for (int i = 0; i < n; i++) {
        arr[i] = (data8_t)((rand() % 51) - 25);  // Range [-25, 25]
    }
}

static void fill_const_int8(data8_t *arr, int n, int8_t val)
{
    for (int i = 0; i < n; i++) arr[i] = (data8_t)val;
}

static void fill_random_int32(acc32_t *arr, int n, int seed = 99)
{
    srand(seed);
    for (int i = 0; i < n; i++) {
        arr[i] = (acc32_t)((rand() % 201) - 100);  // Range [-100, 100]
    }
}

// ---------------------------------------------------------------------------
// Helper: pack flat arrays into 4D arrays (for reference model)
// ---------------------------------------------------------------------------
// Input shape: [in_h][in_w][in_c]  (row-major, channels last)
// Weight shape: [out_c][in_c][k][k]
static void pack_input(
    const data8_t *flat, int in_h, int in_w, int in_c,
    data8_t dst[MAX_IN_H][MAX_IN_W][MAX_IN_C])
{
    memset(dst, 0, sizeof(data8_t) * MAX_IN_H * MAX_IN_W * MAX_IN_C);
    for (int h = 0; h < in_h; h++)
        for (int w = 0; w < in_w; w++)
            for (int c = 0; c < in_c; c++)
                dst[h][w][c] = flat[(h * in_w + w) * in_c + c];
}

static void pack_weights(
    const data8_t *flat, int out_c, int in_c, int k,
    data8_t dst[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K])
{
    memset(dst, 0, sizeof(data8_t) * MAX_OUT_C * MAX_IN_C * MAX_K * MAX_K);
    for (int oc = 0; oc < out_c; oc++)
        for (int ic = 0; ic < in_c; ic++)
            for (int kh = 0; kh < k; kh++)
                for (int kw = 0; kw < k; kw++)
                    dst[oc][ic][kh][kw] = flat[((oc * in_c + ic) * k + kh) * k + kw];
}

// ---------------------------------------------------------------------------
// Helper: stream data to HLS function and collect output
// ---------------------------------------------------------------------------
static void run_hls_conv(
    const data8_t *in_flat, int in_h, int in_w, int in_c,
    const data8_t  weights_4d[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K],
    const acc32_t  bias_arr[MAX_OUT_C],
    const ConvConfig &cfg,
    out8_t *out_flat)
{
    hls::stream<axis8_t> s_in("input_stream");
    hls::stream<axis8_t> s_out("output_stream");

    // Push input pixels into stream
    int total_in = in_h * in_w * in_c;
    for (int i = 0; i < total_in; i++) {
        axis8_t pkt;
        pkt.data = (ap_uint<8>)(uint8_t)(int8_t)in_flat[i];
        pkt.last = (i == total_in - 1) ? 1 : 0;
        pkt.keep = 0xFF;
        pkt.strb = 0xFF;
        s_in.write(pkt);
    }

    // Call HLS top-level function
    conv_engine(s_in, s_out, weights_4d, bias_arr, cfg);

    // Drain output stream
    int out_h_dim = (cfg.in_h + 2 * cfg.pad - cfg.k) / cfg.stride + 1;
    int out_w_dim = (cfg.in_w + 2 * cfg.pad - cfg.k) / cfg.stride + 1;
    int total_out = out_h_dim * out_w_dim * cfg.out_c;
    for (int i = 0; i < total_out; i++) {
        axis8_t pkt = s_out.read();
        out_flat[i] = (out8_t)(int8_t)(uint8_t)pkt.data;
    }
}

// ---------------------------------------------------------------------------
// Core test runner
// ---------------------------------------------------------------------------
static bool run_test(
    const char *name,
    int in_h, int in_w, int in_c, int out_c, int k, int stride, int pad,
    int scale, int shift, int zero_point,
    int data_seed = 42, int weight_seed = 77, int bias_seed = 33)
{
    total_tests++;
    printf("\n=== TEST: %s ===\n", name);
    printf("  Config: in=%d×%d×%d  out_c=%d  k=%d  stride=%d  pad=%d\n",
           in_h, in_w, in_c, out_c, k, stride, pad);
    printf("  Quantization: scale=%d  shift=%d  zero=%d\n", scale, shift, zero_point);

    // Validate config fits in MAX dimensions
    if (in_h > MAX_IN_H || in_w > MAX_IN_W || in_c > MAX_IN_C || out_c > MAX_OUT_C || k > MAX_K) {
        printf("  [SKIP] Config exceeds MAX dimensions\n");
        return true;  // Not a failure
    }

    // Allocate and fill data
    static data8_t in_flat[MAX_IN_H * MAX_IN_W * MAX_IN_C];
    static data8_t w_flat [MAX_OUT_C * MAX_IN_C * MAX_K * MAX_K];
    static acc32_t bias_arr[MAX_OUT_C];

    static data8_t weights_4d[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K];
    static data8_t input_4d  [MAX_IN_H][MAX_IN_W][MAX_IN_C];
    static out8_t  ref_out   [MAX_IN_H][MAX_IN_W][MAX_OUT_C];
    static out8_t  hls_out   [MAX_IN_H * MAX_IN_W * MAX_OUT_C];

    fill_random_int8(in_flat, in_h * in_w * in_c, data_seed);
    fill_random_int8(w_flat, out_c * in_c * k * k, weight_seed);
    fill_random_int32(bias_arr, out_c, bias_seed);

    // Zero extended dimensions
    for (int i = out_c; i < MAX_OUT_C; i++) bias_arr[i] = 0;

    pack_input  (in_flat, in_h, in_w, in_c, input_4d);
    pack_weights(w_flat, out_c, in_c, k, weights_4d);

    ConvConfig cfg;
    cfg.in_h      = in_h;
    cfg.in_w      = in_w;
    cfg.in_c      = in_c;
    cfg.out_c     = out_c;
    cfg.k         = k;
    cfg.stride    = stride;
    cfg.pad       = pad;
    cfg.act_scale = scale;
    cfg.act_shift = shift;
    cfg.act_zero  = zero_point;

    // Run reference
    memset(ref_out, 0, sizeof(ref_out));
    conv_reference(input_4d, weights_4d, bias_arr, ref_out, cfg);

    // Run HLS accelerator
    memset(hls_out, 0, sizeof(hls_out));
    run_hls_conv(in_flat, in_h, in_w, in_c, weights_4d, bias_arr, cfg, hls_out);

    // Compare outputs
    int out_h_dim = (in_h + 2 * pad - k) / stride + 1;
    int out_w_dim = (in_w + 2 * pad - k) / stride + 1;
    int mismatches = 0;
    for (int oh = 0; oh < out_h_dim; oh++) {
        for (int ow = 0; ow < out_w_dim; ow++) {
            for (int oc = 0; oc < out_c; oc++) {
                int ref_val = (int)(int8_t)ref_out[oh][ow][oc];
                int hls_val = (int)(int8_t)hls_out[(oh * out_w_dim + ow) * out_c + oc];
                if (ref_val != hls_val) {
                    mismatches++;
                    if (mismatches <= 5) {
                        printf("  MISMATCH [oh=%d ow=%d oc=%d]: ref=%d hls=%d\n",
                               oh, ow, oc, ref_val, hls_val);
                    }
                }
            }
        }
    }

    int total_out = out_h_dim * out_w_dim * out_c;
    printf("  Output: %d×%d×%d = %d elements\n", out_h_dim, out_w_dim, out_c, total_out);

    if (mismatches == 0) {
        printf("  [PASS] All %d output elements match reference.\n", total_out);
        passed_tests++;
        return true;
    } else {
        printf("  [FAIL] %d/%d mismatches found.\n", mismatches, total_out);
        failed_tests++;
        return false;
    }
}

// ---------------------------------------------------------------------------
// Special test: zero weights → output should be requantized bias only
// ---------------------------------------------------------------------------
static bool test_zero_weights()
{
    total_tests++;
    printf("\n=== TEST: Zero Weights (bias-only) ===\n");

    ConvConfig cfg;
    cfg.in_h = 4; cfg.in_w = 4; cfg.in_c = 2; cfg.out_c = 2;
    cfg.k = 3; cfg.stride = 1; cfg.pad = 1;
    cfg.act_scale = 1; cfg.act_shift = 0; cfg.act_zero = 0;

    static data8_t weights_4d[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K];
    static acc32_t bias_arr[MAX_OUT_C];
    static data8_t input_4d[MAX_IN_H][MAX_IN_W][MAX_IN_C];
    static out8_t  ref_out[MAX_IN_H][MAX_IN_W][MAX_OUT_C];
    static out8_t  hls_out[MAX_IN_H * MAX_IN_W * MAX_OUT_C];
    static data8_t in_flat[MAX_IN_H * MAX_IN_W * MAX_IN_C];

    memset(weights_4d, 0, sizeof(weights_4d));
    bias_arr[0] = 10; bias_arr[1] = -5;
    for (int i = 2; i < MAX_OUT_C; i++) bias_arr[i] = 0;

    fill_random_int8(in_flat, cfg.in_h * cfg.in_w * cfg.in_c, 123);
    pack_input(in_flat, cfg.in_h, cfg.in_w, cfg.in_c, input_4d);

    conv_reference(input_4d, weights_4d, bias_arr, ref_out, cfg);
    run_hls_conv(in_flat, cfg.in_h, cfg.in_w, cfg.in_c, weights_4d, bias_arr, cfg, hls_out);

    int out_h = 4, out_w = 4;
    int mismatches = 0;
    for (int oh = 0; oh < out_h; oh++)
        for (int ow = 0; ow < out_w; ow++)
            for (int oc = 0; oc < cfg.out_c; oc++) {
                int ref_v = (int)(int8_t)ref_out[oh][ow][oc];
                int hls_v = (int)(int8_t)hls_out[(oh * out_w + ow) * cfg.out_c + oc];
                if (ref_v != hls_v) mismatches++;
            }

    if (mismatches == 0) {
        printf("  [PASS] Zero-weight test passed.\n");
        passed_tests++;
        return true;
    } else {
        printf("  [FAIL] %d mismatches in zero-weight test.\n", mismatches);
        failed_tests++;
        return false;
    }
}

// ---------------------------------------------------------------------------
// Special test: saturation
// Use max-value inputs and weights to verify INT8 clamping
// ---------------------------------------------------------------------------
static bool test_saturation()
{
    total_tests++;
    printf("\n=== TEST: Saturation / Overflow ===\n");

    ConvConfig cfg;
    cfg.in_h = 3; cfg.in_w = 3; cfg.in_c = 1; cfg.out_c = 1;
    cfg.k = 3; cfg.stride = 1; cfg.pad = 0;
    cfg.act_scale = 1; cfg.act_shift = 0; cfg.act_zero = 0;

    static data8_t weights_4d[MAX_OUT_C][MAX_IN_C][MAX_K][MAX_K];
    static acc32_t bias_arr[MAX_OUT_C];
    static data8_t input_4d[MAX_IN_H][MAX_IN_W][MAX_IN_C];
    static out8_t  ref_out[MAX_IN_H][MAX_IN_W][MAX_OUT_C];
    static out8_t  hls_out[MAX_IN_H * MAX_IN_W * MAX_OUT_C];
    static data8_t in_flat[MAX_IN_H * MAX_IN_W * MAX_IN_C];

    // Use max positive values → should saturate to 127
    fill_const_int8(in_flat, 9, 127);
    fill_const_int8((data8_t*)weights_4d, MAX_OUT_C * MAX_IN_C * MAX_K * MAX_K, 1);
    bias_arr[0] = 0;
    for (int i = 1; i < MAX_OUT_C; i++) bias_arr[i] = 0;
    pack_input(in_flat, cfg.in_h, cfg.in_w, cfg.in_c, input_4d);

    conv_reference(input_4d, weights_4d, bias_arr, ref_out, cfg);
    run_hls_conv(in_flat, cfg.in_h, cfg.in_w, cfg.in_c, weights_4d, bias_arr, cfg, hls_out);

    int ref_v = (int)(int8_t)ref_out[0][0][0];
    int hls_v = (int)(int8_t)hls_out[0];
    printf("  Input=127×9, weight=1×9: acc=1143, expected saturated=127\n");
    printf("  ref=%d  hls=%d\n", ref_v, hls_v);

    if (ref_v == hls_v) {
        printf("  [PASS] Saturation test passed.\n");
        passed_tests++;
        return true;
    } else {
        printf("  [FAIL] Saturation mismatch.\n");
        failed_tests++;
        return false;
    }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
int main()
{
    printf("============================================================\n");
    printf("  conv_engine C Simulation Testbench\n");
    printf("  ZedBoard XC7Z020 CNN Accelerator\n");
    printf("  BECE406E FPGA-Based System Design, VIT\n");
    printf("============================================================\n");

    // Test 1: Minimal 3×3 conv, 1 channel in, 1 channel out
    run_test("3x3 Conv 1ch→1ch (baseline)",
             /*in_h*/5, /*in_w*/5, /*in_c*/1, /*out_c*/1,
             /*k*/3, /*stride*/1, /*pad*/0,
             /*scale*/1, /*shift*/0, /*zero*/0);

    // Test 2: 3×3 conv, 4 channels
    run_test("3x3 Conv 4ch→4ch",
             5, 5, 4, 4, 3, 1, 0, 1, 0, 0);

    // Test 3: 3×3 conv with stride=2 (spatial downsampling)
    run_test("3x3 Conv stride=2",
             8, 8, 4, 4, 3, 2, 0, 1, 0, 0, 55, 66);

    // Test 4: 3×3 conv with padding=1 (same padding, output size = input size)
    run_test("3x3 Conv pad=1 (same padding)",
             6, 6, 4, 4, 3, 1, 1, 1, 0, 0, 11, 22);

    // Test 5: 1×1 pointwise convolution
    run_test("1x1 Pointwise Conv",
             8, 8, 8, 8, 1, 1, 0, 1, 0, 0, 33, 44);

    // Test 6: Larger tensor (near MAX dimensions)
    run_test("3x3 Conv 8ch→8ch larger",
             14, 14, 8, 8, 3, 1, 1, 1, 0, 0, 77, 88);

    // Test 7: Stride=2, same padding
    run_test("3x3 Conv stride=2 pad=1",
             8, 8, 4, 4, 3, 2, 1, 1, 0, 0, 99, 100);

    // Test 8: Zero weights
    test_zero_weights();

    // Test 9: Saturation
    test_saturation();

    // Summary
    printf("\n============================================================\n");
    printf("  TEST SUMMARY\n");
    printf("  Total:  %d\n", total_tests);
    printf("  Passed: %d\n", passed_tests);
    printf("  Failed: %d\n", failed_tests);
    printf("============================================================\n");

    if (failed_tests > 0) {
        printf("\nC SIMULATION: FAILED\n");
        return 1;
    } else {
        printf("\nC SIMULATION: PASSED\n");
        return 0;
    }
}
