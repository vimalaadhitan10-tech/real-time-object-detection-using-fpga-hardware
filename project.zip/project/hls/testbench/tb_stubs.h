// ===========================================================================
// tb_stubs.h
// Lightweight stub implementations of Vitis HLS headers
// for standalone compilation of the testbench WITHOUT Vitis HLS installed.
//
// Project: Real-Time CNN Object Detection on ZedBoard
// Course:  BECE406E FPGA-Based System Design, VIT
//
// Usage:
//   When Vitis HLS is NOT installed, compile the testbench with:
//     g++ -std=c++17 -D__STANDALONE__ -I. tb_stubs.h tb_conv_engine.cpp
//                                        ../src/conv_engine.cpp
//
//   This file provides:
//     - ap_int<N>    → std::int8_t / std::int32_t typedefs
//     - ap_uint<N>   → std::uint8_t typedef
//     - ap_axiu<W>   → simple struct
//     - hls::stream  → std::queue wrapper
//
//   Limitations:
//     - No AXI-Stream simulation model (just a queue)
//     - No synthesis pragmas (ignored)
//     - Suitable for C++ functional verification ONLY
// ===========================================================================

#ifndef TB_STUBS_H
#define TB_STUBS_H

#ifndef __HLS_SIM__

#include <cstdint>
#include <cstring>
#include <cassert>
#include <queue>

// ---------------------------------------------------------------------------
// ap_int<N> stub — simplified to int8_t or int32_t based on width
// ---------------------------------------------------------------------------
template<int W>
struct ap_int_stub {
    using type = typename std::conditional<(W <= 8), int8_t,
                 typename std::conditional<(W <= 16), int16_t, int32_t>::type>::type;
};

template<int W>
using ap_int = typename ap_int_stub<W>::type;

// ap_uint<N> stub
template<int W>
struct ap_uint_stub {
    using type = typename std::conditional<(W <= 8), uint8_t,
                 typename std::conditional<(W <= 16), uint16_t, uint32_t>::type>::type;
};

template<int W>
using ap_uint = typename ap_uint_stub<W>::type;

// ---------------------------------------------------------------------------
// ap_axiu<W,0,0,0> stub — AXI-Stream packet
// ---------------------------------------------------------------------------
template<int W, int X, int Y, int Z>
struct ap_axiu {
    ap_uint<W>   data;
    ap_uint<W/8> keep;
    ap_uint<W/8> strb;
    ap_uint<1>   last;
};

// For convenience (matches HLS naming)
template<int W, int X, int Y, int Z>
using ap_axis = ap_axiu<W, X, Y, Z>;

// ---------------------------------------------------------------------------
// hls::stream stub — wraps std::queue
// ---------------------------------------------------------------------------
namespace hls {
    template<typename T>
    class stream {
    public:
        stream(const char* = "") {}
        void write(const T& val) { q.push(val); }
        T    read()              { T v = q.front(); q.pop(); return v; }
        bool empty()             { return q.empty(); }
        size_t size()            { return q.size(); }
    private:
        std::queue<T> q;
    };
}

// ---------------------------------------------------------------------------
// HLS pragma stubs — ignored during standalone compilation
// ---------------------------------------------------------------------------
#define HLS_PRAGMA_IGNORE(...)   // empty

// Suppress HLS-specific pragmas when compiling standalone
// The pragmas in conv_engine.cpp use #pragma HLS which the compiler ignores.

#endif // __HLS_SIM__
#endif // TB_STUBS_H
