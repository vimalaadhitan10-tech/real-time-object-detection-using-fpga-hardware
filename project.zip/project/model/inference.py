#!/usr/bin/env python3
"""
inference.py — Software CNN Inference Pipeline
Real-Time CNN Object Detection on ZedBoard (XC7Z020)
Course: BECE406E FPGA-Based System Design, VIT

This script runs YOLOv5n inference on CPU using the Ultralytics framework.
It serves as the software baseline before FPGA deployment.

Usage:
    # Smoke test (downloads YOLOv5n weights automatically)
    python model/inference.py --source data/sample_images/ --output results/

    # With specific weights
    python model/inference.py --weights runs/train/yolov5n/weights/best.pt
                               --source path/to/image.jpg --output results/

    # With confidence and IoU thresholds
    python model/inference.py --source images/ --conf 0.3 --iou 0.45

    # With specific input size (use 320 for faster inference)
    python model/inference.py --source images/ --imgsz 320
"""

import argparse
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np


def parse_args():
    parser = argparse.ArgumentParser(
        description="YOLOv5n Inference — ZedBoard CNN Project",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument("--weights",  type=str,   default="yolov5n.pt",
                        help="Model weights path. 'yolov5n.pt' downloads automatically.")
    parser.add_argument("--source",   type=str,   default="data/sample_images",
                        help="Input: image path, directory, or 0 for webcam.")
    parser.add_argument("--output",   type=str,   default="results",
                        help="Output directory for annotated images.")
    parser.add_argument("--imgsz",    type=int,   default=416,
                        help="Inference input size (pixels). Use 320 for speed.")
    parser.add_argument("--conf",     type=float, default=0.25,
                        help="Object confidence threshold.")
    parser.add_argument("--iou",      type=float, default=0.45,
                        help="NMS IoU threshold.")
    parser.add_argument("--device",   type=str,   default="cpu",
                        help="Inference device: 'cpu' or '0' for GPU.")
    parser.add_argument("--save-txt", action="store_true",
                        help="Save detection results as .txt (YOLO format).")
    parser.add_argument("--no-display", action="store_true",
                        help="Do not display results (for headless environments).")
    parser.add_argument("--benchmark", action="store_true",
                        help="Run benchmark mode (multiple passes, report FPS).")
    parser.add_argument("--benchmark-runs", type=int, default=50,
                        help="Number of inference passes for benchmark.")
    return parser.parse_args()


def load_model(weights_path: str, device: str):
    """Load YOLOv5n model via Ultralytics."""
    try:
        from ultralytics import YOLO
        print(f"[INFO] Loading model: {weights_path}")
        model = YOLO(weights_path)
        print(f"[INFO] Model loaded — device: {device}")
        return model, "ultralytics"
    except ImportError:
        print("[ERROR] ultralytics not installed. Run: pip install ultralytics")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Failed to load model: {e}")
        print("  Ensure weights file exists or use 'yolov5n.pt' for auto-download.")
        sys.exit(1)


def collect_sources(source: str):
    """Collect image paths from source (file, directory, or webcam)."""
    source = Path(source)

    if source == Path("0") or str(source).isdigit():
        return [int(str(source))]  # Webcam

    if source.is_file():
        if source.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp", ".tiff"]:
            return [source]
        else:
            print(f"[WARNING] Unsupported file type: {source.suffix}")
            return []

    if source.is_dir():
        imgs = []
        for ext in ["*.jpg", "*.jpeg", "*.png", "*.bmp"]:
            imgs.extend(sorted(source.glob(ext)))
            imgs.extend(sorted(source.glob(ext.upper())))
        if not imgs:
            print(f"[WARNING] No images found in {source}")
        return imgs

    print(f"[WARNING] Source not found: {source}")
    return []


def run_inference(args):
    """Main inference function."""

    # Setup output directory
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load model
    model, backend = load_model(args.weights, args.device)

    # Collect input sources
    sources = collect_sources(args.source)
    if not sources:
        print("[ERROR] No valid input sources found.")
        print(f"  Create sample images in: {args.source}")
        print("  Or provide --source path/to/image.jpg")
        return

    print(f"\n[INFO] Input size:    {args.imgsz}×{args.imgsz}")
    print(f"[INFO] Confidence:    {args.conf}")
    print(f"[INFO] IoU threshold: {args.iou}")
    print(f"[INFO] Sources:       {len(sources)} image(s)")
    print(f"[INFO] Output:        {output_dir}\n")

    # Benchmark mode: warm up then time
    if args.benchmark and len(sources) > 0:
        print(f"[BENCHMARK] Warming up...")
        model.predict(
            str(sources[0]), imgsz=args.imgsz, conf=args.conf,
            iou=args.iou, device=args.device, verbose=False
        )

        print(f"[BENCHMARK] Running {args.benchmark_runs} inference passes...")
        t0 = time.perf_counter()
        for _ in range(args.benchmark_runs):
            model.predict(
                str(sources[0]), imgsz=args.imgsz, conf=args.conf,
                iou=args.iou, device=args.device, verbose=False
            )
        t1 = time.perf_counter()

        elapsed = t1 - t0
        fps = args.benchmark_runs / elapsed
        ms_per_frame = elapsed / args.benchmark_runs * 1000

        print(f"\n[BENCHMARK RESULTS]")
        print(f"  Runs:         {args.benchmark_runs}")
        print(f"  Total time:   {elapsed:.3f} s")
        print(f"  Latency:      {ms_per_frame:.1f} ms/frame")
        print(f"  Throughput:   {fps:.1f} FPS (CPU)")
        print(f"  Device:       {args.device}")
        print(f"  Input size:   {args.imgsz}×{args.imgsz}")
        print(f"  Model:        {args.weights}")

        # Save benchmark results
        bench_file = output_dir / "benchmark_results.txt"
        with open(bench_file, "w") as f:
            f.write(f"YOLOv5n CPU Benchmark Results\n")
            f.write(f"{'='*40}\n")
            f.write(f"Model:        {args.weights}\n")
            f.write(f"Input size:   {args.imgsz}x{args.imgsz}\n")
            f.write(f"Device:       {args.device}\n")
            f.write(f"Runs:         {args.benchmark_runs}\n")
            f.write(f"Total time:   {elapsed:.3f} s\n")
            f.write(f"Latency:      {ms_per_frame:.1f} ms/frame\n")
            f.write(f"Throughput:   {fps:.1f} FPS\n")
            f.write(f"\nNote: FPGA target is >=25 FPS at <10W.\n")
        print(f"\n[INFO] Results saved: {bench_file}")
        return

    # Normal inference loop
    total_detections = 0
    inference_times = []

    for i, src in enumerate(sources):
        src_str = str(src)
        print(f"[{i+1}/{len(sources)}] Processing: {Path(src_str).name}")

        t0 = time.perf_counter()
        results = model.predict(
            src_str,
            imgsz=args.imgsz,
            conf=args.conf,
            iou=args.iou,
            device=args.device,
            verbose=False,
            save=False,         # We handle saving manually
        )
        t1 = time.perf_counter()

        inference_time_ms = (t1 - t0) * 1000
        inference_times.append(inference_time_ms)

        for result in results:
            boxes = result.boxes
            n_det = len(boxes) if boxes is not None else 0
            total_detections += n_det
            print(f"  Detections: {n_det}  |  Time: {inference_time_ms:.1f} ms")

            # Print detections
            if boxes is not None and len(boxes) > 0:
                for box in boxes:
                    cls_id = int(box.cls[0])
                    conf   = float(box.conf[0])
                    xyxy   = box.xyxy[0].tolist()
                    cls_name = result.names.get(cls_id, str(cls_id))
                    print(f"    [{cls_name}] conf={conf:.3f} box=[{xyxy[0]:.0f},{xyxy[1]:.0f},{xyxy[2]:.0f},{xyxy[3]:.0f}]")

            # Save annotated image
            annotated = result.plot()
            out_path = output_dir / f"result_{Path(src_str).stem}.jpg"
            cv2.imwrite(str(out_path), annotated)

            # Save YOLO-format txt
            if args.save_txt and boxes is not None:
                txt_path = output_dir / f"result_{Path(src_str).stem}.txt"
                with open(txt_path, "w") as f:
                    for box in boxes:
                        cls_id = int(box.cls[0])
                        xywhn  = box.xywhn[0].tolist()
                        conf   = float(box.conf[0])
                        f.write(f"{cls_id} {xywhn[0]:.6f} {xywhn[1]:.6f} {xywhn[2]:.6f} {xywhn[3]:.6f} {conf:.6f}\n")

    # Summary
    print(f"\n{'='*50}")
    print(f"INFERENCE SUMMARY")
    print(f"{'='*50}")
    print(f"  Images processed: {len(sources)}")
    print(f"  Total detections: {total_detections}")
    if inference_times:
        avg_ms  = sum(inference_times) / len(inference_times)
        avg_fps = 1000.0 / avg_ms if avg_ms > 0 else 0
        print(f"  Avg latency:      {avg_ms:.1f} ms/frame")
        print(f"  Avg throughput:   {avg_fps:.1f} FPS (CPU only)")
        print(f"  FPGA target:      ≥25 FPS at <10W")
    print(f"  Results saved to: {output_dir}")


def create_sample_images(output_dir: str = "data/sample_images"):
    """Create synthetic sample images for smoke testing (no real dataset needed)."""
    import numpy as np
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] Creating synthetic sample images in {out}/")

    # Image 1: Gradient
    img1 = np.zeros((480, 640, 3), dtype=np.uint8)
    for h in range(480):
        for w in range(640):
            img1[h, w, 0] = int(h * 255 / 480)
            img1[h, w, 1] = int(w * 255 / 640)
            img1[h, w, 2] = 128
    cv2.imwrite(str(out / "sample_gradient.jpg"), img1)

    # Image 2: Checkerboard
    img2 = np.zeros((480, 640, 3), dtype=np.uint8)
    block = 40
    for h in range(480):
        for w in range(640):
            if ((h // block) + (w // block)) % 2 == 0:
                img2[h, w, :] = [200, 200, 200]
            else:
                img2[h, w, :] = [50, 50, 50]
    cv2.imwrite(str(out / "sample_checkerboard.jpg"), img2)

    # Image 3: Random noise
    img3 = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
    cv2.imwrite(str(out / "sample_noise.jpg"), img3)

    print(f"[INFO] Created 3 synthetic sample images.")
    return out


if __name__ == "__main__":
    args = parse_args()

    # Auto-create sample images if source doesn't exist
    source_path = Path(args.source)
    if not source_path.exists():
        print(f"[INFO] Source '{args.source}' not found. Creating sample images...")
        create_sample_images(args.source)

    run_inference(args)
