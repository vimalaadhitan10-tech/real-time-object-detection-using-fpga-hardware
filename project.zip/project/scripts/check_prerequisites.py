#!/usr/bin/env python3
"""
check_prerequisites.py — Environment verification script
Real-Time CNN Object Detection on ZedBoard
BECE406E FPGA-Based System Design, VIT

Checks all required tools, Python packages, and project structure.
Generates a status report.

Usage:
    python scripts/check_prerequisites.py
"""

import sys
import os
import importlib
import subprocess
import platform
import json
from pathlib import Path

# Project root = parent of this script's directory
PROJECT_ROOT = Path(__file__).parent.parent

CHECKS_PASSED = []
CHECKS_FAILED = []
CHECKS_WARNING = []


def check(name, passed, message="", level="FAIL"):
    status = "✓ PASS" if passed else ("⚠ WARN" if level == "WARN" else "✗ FAIL")
    print(f"  {status}  {name}")
    if message:
        print(f"         {message}")
    if passed:
        CHECKS_PASSED.append(name)
    elif level == "WARN":
        CHECKS_WARNING.append(name)
    else:
        CHECKS_FAILED.append(name)
    return passed


def section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


# ============================================================================
# System checks
# ============================================================================

section("System Information")
print(f"  OS:       {platform.system()} {platform.release()} {platform.architecture()[0]}")
print(f"  CPU:      {platform.processor() or 'Unknown'}")
print(f"  Python:   {sys.version}")

# Disk space
import shutil
total, used, free = shutil.disk_usage("/")
free_gb = free / (1024**3)
print(f"  Disk:     {free_gb:.1f} GB free (need ~20 GB for datasets + tools)")
check("Disk space ≥ 20 GB", free_gb >= 20,
      f"{free_gb:.1f} GB free — COCO dataset needs ~20 GB",
      level="WARN" if free_gb >= 5 else "FAIL")


# ============================================================================
# Python version
# ============================================================================
section("Python Environment")

py_ok = sys.version_info >= (3, 9)
check(f"Python ≥ 3.9", py_ok,
      f"Found {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")


# ============================================================================
# Python packages
# ============================================================================
section("Python Packages")

def check_pkg(pkg_name, import_name=None, min_version=None):
    import_name = import_name or pkg_name
    try:
        mod = importlib.import_module(import_name)
        version = getattr(mod, "__version__", "unknown")

        version_ok = True
        if min_version:
            try:
                from packaging.version import Version
                version_ok = Version(version) >= Version(min_version)
            except Exception:
                # Without packaging, just accept
                version_ok = True

        check(f"{pkg_name}", version_ok,
              f"version {version}" + (f" (need ≥{min_version})" if not version_ok else ""))
        return version
    except ImportError:
        check(f"{pkg_name}", False, f"NOT INSTALLED — pip install {pkg_name}")
        return None

torch_ver = check_pkg("torch", "torch", "2.0.0")
check_pkg("torchvision", "torchvision", "0.15.0")
check_pkg("ultralytics", "ultralytics", "8.0.0")
check_pkg("opencv-python", "cv2", "4.8.0")
check_pkg("numpy", "numpy", "1.24.0")
check_pkg("Pillow", "PIL", "10.0.0")
check_pkg("PyYAML", "yaml")
check_pkg("scipy", "scipy")
check_pkg("matplotlib", "matplotlib")

# CUDA check
section("GPU / CUDA")
try:
    import torch
    cuda_avail = torch.cuda.is_available()
    check("CUDA available", cuda_avail,
          "No GPU found — CPU inference only (slower)" if not cuda_avail else
          f"GPU: {torch.cuda.get_device_name(0)}",
          level="WARN")
except Exception:
    check("CUDA check", False, "Cannot check CUDA", level="WARN")

# ONNX
section("Optional Packages (for export)")
for pkg in ["onnx", "onnxruntime", "pandas", "seaborn", "pytest"]:
    check_pkg(pkg, pkg, level="WARN") if False else None
    try:
        mod = importlib.import_module(pkg)
        ver = getattr(mod, "__version__", "?")
        check(f"{pkg}", True, f"version {ver}")
    except ImportError:
        check(f"{pkg}", False, f"OPTIONAL — pip install {pkg}", level="WARN")


# ============================================================================
# External tools
# ============================================================================
section("External Tools")

def check_cmd(name, cmd, version_flag="--version", level="FAIL"):
    try:
        result = subprocess.run([cmd, version_flag], capture_output=True, text=True, timeout=5)
        output = (result.stdout + result.stderr).strip().split("\n")[0]
        check(name, True, output[:80])
        return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        check(name, False, f"NOT FOUND — install {name}", level=level)
        return False

check_cmd("Git",        "git",        "--version", level="WARN")
check_cmd("GCC/MinGW",  "gcc",        "--version", level="WARN")
check_cmd("Vivado",     "vivado",     "-version",  level="WARN")
check_cmd("Vitis HLS",  "vitis_hls",  "-version",  level="WARN")
check_cmd("Vitis IDE",  "vitis",      "-version",  level="WARN")


# ============================================================================
# Project structure
# ============================================================================
section("Project Structure")

required_dirs = [
    "docs", "model", "hls/src", "hls/testbench", "hls/scripts",
    "fpga/scripts", "fpga/constraints", "software/common",
    "software/baremetal", "scripts", "tests", "deployment", "results"
]
required_files = [
    "README.md", "requirements.txt", ".gitignore",
    "model/inference.py", "model/quantize.py",
    "hls/src/conv_engine.h", "hls/src/conv_engine.cpp",
    "hls/testbench/tb_conv_engine.cpp", "hls/testbench/ref_conv.py",
    "hls/scripts/run_hls.tcl",
    "fpga/scripts/build.tcl", "fpga/constraints/zedboard.xdc",
    "software/common/cnn_accelerator.h", "software/common/cnn_accelerator.c",
    "software/baremetal/main.c",
    "scripts/check_prerequisites.py",
    "tests/test_preprocessing.py", "tests/test_model.py",
]

for d in required_dirs:
    path = PROJECT_ROOT / d
    check(f"Directory: {d}", path.is_dir())

for f in required_files:
    path = PROJECT_ROOT / f
    size = path.stat().st_size if path.exists() else 0
    check(f"File: {f}", path.exists() and size > 0,
          f"{size} bytes" if path.exists() else "MISSING")


# ============================================================================
# Dataset status
# ============================================================================
section("Dataset Status")

data_dirs = [
    ("data/sample_images", "Smoke test images", False),
    ("data/calib",         "PTQ calibration images", True),
    ("data/coco",          "COCO 2017 dataset", True),
    ("data/voc",           "PASCAL VOC dataset", True),
]

for rel_path, desc, optional in data_dirs:
    path = PROJECT_ROOT / rel_path
    if path.exists():
        files = list(path.glob("**/*"))
        n = len([f for f in files if f.is_file()])
        check(f"{desc} ({rel_path})", True, f"{n} files found")
    else:
        lvl = "WARN" if optional else "WARN"
        check(f"{desc} ({rel_path})", False,
              "Not present — run scripts/prepare_dataset.py", level=lvl)


# ============================================================================
# Model weights status
# ============================================================================
section("Model Weights")

weight_files = [
    ("yolov5n.pt",           "YOLOv5n FP32 weights (auto-download on first inference)"),
    ("model/yolov5n_int8.onnx", "INT8 ONNX model (run model/quantize.py --mode ptq)"),
]

for fname, desc in weight_files:
    path = PROJECT_ROOT / fname
    # Also check Ultralytics cache
    cache_path = Path.home() / ".cache" / "ultralytics" / fname
    found = path.exists() or cache_path.exists()
    size_mb = path.stat().st_size / 1e6 if path.exists() else (
              cache_path.stat().st_size / 1e6 if cache_path.exists() else 0)
    check(f"{fname}", found,
          f"{size_mb:.1f} MB — {desc}" if found else desc,
          level="WARN")


# ============================================================================
# Summary
# ============================================================================
section("Summary")

total = len(CHECKS_PASSED) + len(CHECKS_FAILED) + len(CHECKS_WARNING)
print(f"\n  Total checks:   {total}")
print(f"  Passed:         {len(CHECKS_PASSED)} ✓")
print(f"  Warnings:       {len(CHECKS_WARNING)} ⚠")
print(f"  Failed:         {len(CHECKS_FAILED)} ✗")

if CHECKS_FAILED:
    print(f"\n  FAILED checks:")
    for c in CHECKS_FAILED:
        print(f"    ✗ {c}")

if CHECKS_WARNING:
    print(f"\n  WARNING checks:")
    for c in CHECKS_WARNING:
        print(f"    ⚠ {c}")

if not CHECKS_FAILED:
    print("\n  ✓ All critical checks passed. Ready for software pipeline.")
else:
    print(f"\n  ✗ {len(CHECKS_FAILED)} critical issue(s) require attention.")

print(f"\n  Next steps:")
print(f"  1. Install missing packages: pip install -r requirements.txt")
print(f"  2. Run inference:  python model/inference.py --source data/sample_images/")
print(f"  3. Run tests:      python scripts/run_tests.py")
print(f"  4. Install Vivado (2022.2) for HLS synthesis and FPGA build")
print(f"     Download: https://www.xilinx.com/support/download.html")

# Save report
report = {
    "passed": CHECKS_PASSED,
    "warnings": CHECKS_WARNING,
    "failed": CHECKS_FAILED,
    "ready_for_software": len(CHECKS_FAILED) == 0,
    "ready_for_fpga": False,  # Requires Vivado
}
report_path = PROJECT_ROOT / "results" / "prerequisites_report.json"
report_path.parent.mkdir(exist_ok=True)
with open(report_path, "w") as f:
    json.dump(report, f, indent=2)
print(f"\n  Report saved: {report_path}")

sys.exit(0 if not CHECKS_FAILED else 1)
