/* ===========================================================================
 * main.c — Bare-Metal ARM Application
 * Real-Time CNN Object Detection on ZedBoard
 *
 * Project: BECE406E FPGA-Based System Design, VIT
 *
 * Execution flow:
 *   1. Initialize platform (cache, MMU, UART)
 *   2. Initialize CNN accelerator + DMA
 *   3. Load model weights from DDR (pre-loaded by boot loader or JTAG)
 *   4. Load test image (from DDR or UART)
 *   5. Preprocess: resize + normalize + quantize to INT8
 *   6. Run FPGA inference layer by layer
 *   7. Postprocess: decode YOLO anchors + NMS
 *   8. Print results via UART
 *   9. (Optional) display via HDMI
 *
 * Build: Requires Vitis SDK with XSA hardware platform exported from Vivado.
 * Status: SOURCE COMPLETE — not yet compiled (Vitis not installed).
 * =========================================================================== */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include "cnn_accelerator.h"

/* Xilinx BSP headers — available after Vitis project creation */
#ifdef __XILINX_STANDALONE__
  #include "platform.h"
  #include "xil_printf.h"
  #include "xparameters.h"
  #include "sleep.h"
  #define PRINT xil_printf
#else
  #define PRINT printf
  static void init_platform(void)  {}
  static void cleanup_platform(void) {}
#endif

/* ============================================================================
 * YOLOv5n Configuration (must match quantized model)
 * ============================================================================ */

#define YOLO_INPUT_H        416
#define YOLO_INPUT_W        416
#define YOLO_INPUT_C        3
#define YOLO_NUM_CLASSES    80      /* COCO classes — change to 20 for VOC */
#define YOLO_CONF_THRESH    0.25f   /* Confidence threshold */
#define YOLO_IOU_THRESH     0.45f   /* NMS IoU threshold */

/* YOLOv5n anchor boxes (for 3 scales) */
/* These MUST match the anchors used during training/export */
static const float yolo_anchors[3][6] = {
    {10.f, 13.f,  16.f, 30.f,   33.f, 23.f},  /* small */
    {30.f, 61.f,  62.f, 45.f,   59.f, 119.f}, /* medium */
    {116.f, 90.f, 156.f, 198.f, 373.f, 326.f} /* large */
};

/* ============================================================================
 * COCO class names (first 20 shown — loaded from DDR in real system)
 * ============================================================================ */
static const char *coco_names[] = {
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train",
    "truck", "boat", "traffic light", "fire hydrant", "stop sign",
    "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
    /* ... 60 more classes */
};

/* ============================================================================
 * Detection result structure
 * ============================================================================ */
typedef struct {
    float x1, y1, x2, y2;  /* Bounding box in original image coordinates */
    float confidence;        /* Object confidence × class probability */
    int   class_id;          /* Class index */
} detection_t;

#define MAX_DETECTIONS  100

/* ============================================================================
 * Preprocessing: normalize pixel [0,255] to INT8 [-128, 127]
 * Scale: 1/255.0 → INT8 scale ≈ 0.00392 (scale=1, shift=8, zero=-128)
 * ============================================================================ */
static void preprocess_image(
    const uint8_t *rgb_in, int in_h, int in_w,
    int8_t *out, int target_h, int target_w)
{
    /* Simplified bilinear resize + normalization */
    /* In hardware-deployed version, this runs on ARM Cortex-A9 Core 0 */
    float scale_h = (float)in_h / target_h;
    float scale_w = (float)in_w / target_w;

    for (int c = 0; c < 3; c++) {
        for (int h = 0; h < target_h; h++) {
            for (int w = 0; w < target_w; w++) {
                /* Nearest-neighbor interpolation (faster, adequate for demo) */
                int src_h = (int)(h * scale_h);
                int src_w = (int)(w * scale_w);
                if (src_h >= in_h) src_h = in_h - 1;
                if (src_w >= in_w) src_w = in_w - 1;

                uint8_t pixel = rgb_in[(src_h * in_w + src_w) * 3 + c];

                /* Quantize: pixel / 255.0 → [-128, 127] */
                /* Using scale=1.0/255.0, zero_point=-128 */
                int q = (int)pixel - 128;
                if (q < -128) q = -128;
                if (q >  127) q =  127;

                /* CHW layout for accelerator */
                out[c * target_h * target_w + h * target_w + w] = (int8_t)q;
            }
        }
    }
}

/* ============================================================================
 * Sigmoid function (for YOLO output decoding)
 * ============================================================================ */
static inline float sigmoid(float x) { return 1.0f / (1.0f + expf(-x)); }

/* ============================================================================
 * NMS (Non-Maximum Suppression) — simple greedy implementation
 * ============================================================================ */
static float iou(const detection_t *a, const detection_t *b)
{
    float inter_x1 = a->x1 > b->x1 ? a->x1 : b->x1;
    float inter_y1 = a->y1 > b->y1 ? a->y1 : b->y1;
    float inter_x2 = a->x2 < b->x2 ? a->x2 : b->x2;
    float inter_y2 = a->y2 < b->y2 ? a->y2 : b->y2;

    float inter_w = inter_x2 - inter_x1;
    float inter_h = inter_y2 - inter_y1;
    if (inter_w <= 0.f || inter_h <= 0.f) return 0.f;

    float inter_area = inter_w * inter_h;
    float area_a = (a->x2 - a->x1) * (a->y2 - a->y1);
    float area_b = (b->x2 - b->x1) * (b->y2 - b->y1);
    return inter_area / (area_a + area_b - inter_area);
}

static int nms(detection_t *dets, int n, float iou_thresh)
{
    /* Simple O(n²) NMS — adequate for embedded, small n */
    int kept = 0;
    for (int i = 0; i < n; i++) {
        int suppress = 0;
        for (int j = 0; j < i; j++) {
            if (dets[j].confidence > 0.f &&
                dets[j].class_id == dets[i].class_id &&
                iou(&dets[j], &dets[i]) > iou_thresh) {
                suppress = 1;
                break;
            }
        }
        if (!suppress) dets[kept++] = dets[i];
    }
    return kept;
}

/* ============================================================================
 * Main application entry point
 * ============================================================================ */
int main(void)
{
    init_platform();

    PRINT("\n");
    PRINT("============================================================\n");
    PRINT("  Real-Time CNN Object Detection — ZedBoard XC7Z020\n");
    PRINT("  BECE406E FPGA-Based System Design, VIT\n");
    PRINT("============================================================\n\n");

    /* -----------------------------------------------------------------------
     * Step 1: Initialize CNN accelerator and AXI DMA
     * ----------------------------------------------------------------------- */
    PRINT("[1] Initializing CNN accelerator...\n");
    cnn_status_t status = cnn_accel_init();
    if (status != CNN_SUCCESS) {
        PRINT("[ERROR] CNN accelerator init failed: %d\n", status);
        goto error_exit;
    }
    PRINT("    OK — Accelerator idle\n");

    /* -----------------------------------------------------------------------
     * Step 2: Load model weights
     * In deployment, weights are pre-loaded to DDR by FSBL or U-Boot.
     * Address: CNN_WEIGHT_BUF_ADDR (from cnn_accelerator.h)
     * Here we set up the pointer; actual weights must be in DDR.
     * ----------------------------------------------------------------------- */
    PRINT("[2] Loading model weights from DDR (0x%08X)...\n", CNN_WEIGHT_BUF_ADDR);
    /* Weights are expected to be at CNN_WEIGHT_BUF_ADDR in DDR */
    /* Loaded by: FSBL → boot.bin → weights partition */
    /* For demo: assume weights are present (verified by non-zero check) */
    const int8_t  *weights = (const int8_t  *)CNN_WEIGHT_BUF_ADDR;
    const int32_t *bias    = (const int32_t *)(CNN_WEIGHT_BUF_ADDR + CNN_MAX_WEIGHT_BYTES);
    (void)weights; (void)bias;

    PRINT("    Weight address: 0x%08X (verify non-zero after FSBL loads)\n",
          CNN_WEIGHT_BUF_ADDR);

    /* -----------------------------------------------------------------------
     * Step 3: Load test image
     * In deployment: loaded from SD card or received via Ethernet.
     * For demo: use a synthetic gradient image in DDR.
     * ----------------------------------------------------------------------- */
    PRINT("[3] Preparing test image...\n");
    static uint8_t test_image[416 * 416 * 3];
    /* Generate a synthetic test image (gradient pattern) */
    for (int h = 0; h < 416; h++) {
        for (int w = 0; w < 416; w++) {
            test_image[(h * 416 + w) * 3 + 0] = (uint8_t)((h * 255) / 416);  /* R */
            test_image[(h * 416 + w) * 3 + 1] = (uint8_t)((w * 255) / 416);  /* G */
            test_image[(h * 416 + w) * 3 + 2] = 128;                           /* B */
        }
    }
    PRINT("    Test image: 416×416×3 gradient (synthetic)\n");

    /* -----------------------------------------------------------------------
     * Step 4: Preprocess
     * ----------------------------------------------------------------------- */
    PRINT("[4] Preprocessing (resize + quantize)...\n");
    static int8_t input_tensor[YOLO_INPUT_C * YOLO_INPUT_H * YOLO_INPUT_W];
    preprocess_image(test_image, 416, 416, input_tensor, YOLO_INPUT_H, YOLO_INPUT_W);
    PRINT("    Preprocessed to INT8 CHW tensor: %d×%d×%d\n",
          YOLO_INPUT_C, YOLO_INPUT_H, YOLO_INPUT_W);

    /* -----------------------------------------------------------------------
     * Step 5: Run FPGA inference
     * For demonstration, we run the first convolution layer.
     * Full YOLOv5n has ~100+ layers — full pipelining requires
     * all layer weights loaded and sequential layer execution.
     * ----------------------------------------------------------------------- */
    PRINT("[5] Running FPGA convolution (Layer 0: 3→16, 3×3, stride=1)...\n");

    /* First YOLOv5n-like layer: 3→16 channels, 3×3 kernel, stride=1 */
    cnn_layer_config_t layer0_cfg = {
        .in_h      = YOLO_INPUT_H,
        .in_w      = YOLO_INPUT_W,
        .in_c      = 3,
        .out_c     = 16,
        .k         = 3,
        .stride    = 2,
        .pad       = 1,
        .act_scale = 1,
        .act_shift = 0,
        .act_zero  = 0
    };

    /* Note: for this demo, weights pointer points to DDR weight buffer */
    /* In production: load actual quantized YOLOv5n INT8 weights here */
    static int8_t  demo_weights[16 * 3 * 3 * 3];  /* 16×3×3×3 = 432 params */
    static int32_t demo_bias[16];
    static int8_t  layer0_output[208 * 208 * 16];  /* After stride=2: 208×208 */

    /* Initialize demo weights to small values */
    for (int i = 0; i < 16 * 3 * 3 * 3; i++) demo_weights[i] = (int8_t)(i % 7 - 3);
    for (int i = 0; i < 16; i++) demo_bias[i] = 0;

    status = cnn_run_layer(&layer0_cfg, input_tensor, demo_weights, demo_bias, layer0_output);

    if (status != CNN_SUCCESS) {
        PRINT("[ERROR] CNN inference failed: %d\n", status);
        PRINT("  Check AXI DMA and accelerator register connections.\n");
        goto error_exit;
    }

    PRINT("    FPGA inference complete. Output: 208×208×16 INT8 tensor\n");

    /* -----------------------------------------------------------------------
     * Step 6: Postprocessing (on ARM, from full network output)
     * This is a placeholder — full postprocessing requires all 3 detection
     * head outputs from the complete YOLOv5n network.
     * ----------------------------------------------------------------------- */
    PRINT("[6] Postprocessing (detection decode + NMS)...\n");
    PRINT("    [INFO] Full postprocessing requires complete network output.\n");
    PRINT("    [INFO] Currently only Layer 0 is executed on FPGA.\n");
    PRINT("    [INFO] Full network integration pending HLS expansion.\n");

    /* Example detection output (would come from actual YOLO decode) */
    detection_t detections[MAX_DETECTIONS];
    int num_detections = 0;

    /* For now, print that no detections are available from the demo layer */
    PRINT("    Detections found: %d (synthetic demo — real model weights required)\n",
          num_detections);

    /* -----------------------------------------------------------------------
     * Step 7: Report performance
     * ----------------------------------------------------------------------- */
    PRINT("\n[7] Performance Summary:\n");
    PRINT("    Layer 0 input:   %d×%d×%d\n", YOLO_INPUT_H, YOLO_INPUT_W, 3);
    PRINT("    Layer 0 output:  208×208×16\n");
    PRINT("    Accelerator:     XC7Z020 PL @ 100 MHz\n");
    PRINT("    [TIMING] Enable XTime to measure latency\n");

    PRINT("\n============================================================\n");
    PRINT("  Demo complete. Connect camera and load full model for\n");
    PRINT("  real-time object detection.\n");
    PRINT("============================================================\n");

    cleanup_platform();
    return 0;

error_exit:
    PRINT("[ERROR] Application exited with error.\n");
    cleanup_platform();
    return -1;
}
