/* ===========================================================================
 * cnn_accelerator.c
 * ARM Cortex-A9 Driver Implementation for CNN Convolution Accelerator
 *
 * Project: Real-Time CNN Object Detection on ZedBoard
 * Course:  BECE406E FPGA-Based System Design, VIT
 *
 * Build environment: Vitis (Xilinx SDK) for standalone (bare-metal) BSP.
 * The Xil_* functions are provided by the Xilinx standalone BSP.
 *
 * Build status: SOURCE COMPLETE, NOT YET COMPILED
 * Reason: Requires Vitis SDK + XSA hardware platform (not yet generated).
 * Dependency: fpga/build/zedboard_cnn.xsa must exist.
 * =========================================================================== */

#include "cnn_accelerator.h"

/* Xilinx standalone BSP headers (available after Vitis project creation) */
#ifdef __XILINX_STANDALONE__
  #include "xil_io.h"          /* Xil_In32, Xil_Out32 */
  #include "xil_cache.h"       /* Xil_DCacheFlushRange, Xil_DCacheInvalidateRange */
  #include "xil_printf.h"      /* xil_printf */
  #include "xtime_l.h"         /* XTime_GetTime — for timeout */
  #define COUNTS_PER_USEC     (COUNTS_PER_SECOND / 1000000)
#else
  /* Stubs for compilation check without Xilinx tools */
  #include <stdio.h>
  #include <string.h>
  static inline uint32_t Xil_In32(uint32_t addr)   { return 0; }
  static inline void      Xil_Out32(uint32_t a, uint32_t v) {}
  static inline void      Xil_DCacheFlushRange(uint32_t a, uint32_t s) {}
  static inline void      Xil_DCacheInvalidateRange(uint32_t a, uint32_t s) {}
  #define xil_printf printf
  typedef uint64_t XTime;
  static void XTime_GetTime(XTime *t) { *t = 0; }
  #define COUNTS_PER_USEC 100
#endif

/* ============================================================================
 * Static state
 * ============================================================================ */
static int g_initialized = 0;

/* ============================================================================
 * Register access helpers
 * ============================================================================ */

uint32_t cnn_read_reg(uint32_t offset)
{
    return Xil_In32(CNN_ACCEL_BASE + offset);
}

void cnn_write_reg(uint32_t offset, uint32_t value)
{
    Xil_Out32(CNN_ACCEL_BASE + offset, value);
}

uint32_t dma_read_reg(uint32_t offset)
{
    return Xil_In32(DMA_BASE + offset);
}

void dma_write_reg(uint32_t offset, uint32_t value)
{
    Xil_Out32(DMA_BASE + offset, value);
}

/* ============================================================================
 * Cache management
 * ============================================================================ */

void cnn_cache_flush(uint32_t addr, size_t size)
{
    Xil_DCacheFlushRange(addr, (uint32_t)size);
}

void cnn_cache_invalidate(uint32_t addr, size_t size)
{
    Xil_DCacheInvalidateRange(addr, (uint32_t)size);
}

/* ============================================================================
 * Timeout helper — uses ARM PMU cycle counter via XTime
 * ============================================================================ */

static int wait_for_condition_timeout(volatile uint32_t *reg, uint32_t mask,
                                       uint32_t expected, uint32_t timeout_us)
{
    XTime start, now;
    XTime_GetTime(&start);

    while (1) {
        if ((*reg & mask) == expected) return 0;  /* Condition met */

        XTime_GetTime(&now);
        if ((uint64_t)(now - start) >= (uint64_t)timeout_us * COUNTS_PER_USEC) {
            return -1;  /* Timeout */
        }
    }
}

/* ============================================================================
 * AXI DMA helpers
 * ============================================================================ */

static cnn_status_t dma_reset(void)
{
    /* Reset both channels */
    dma_write_reg(DMA_MM2S_CR, DMA_CR_RESET);
    dma_write_reg(DMA_S2MM_CR, DMA_CR_RESET);

    /* Wait for reset to clear (hardware clears reset bit when done) */
    volatile uint32_t timeout = 100000;
    while ((dma_read_reg(DMA_MM2S_CR) & DMA_CR_RESET) && timeout--);
    if (timeout == 0) return CNN_ERR_DMA;

    timeout = 100000;
    while ((dma_read_reg(DMA_S2MM_CR) & DMA_CR_RESET) && timeout--);
    if (timeout == 0) return CNN_ERR_DMA;

    return CNN_SUCCESS;
}

static cnn_status_t dma_start_mm2s(uint32_t src_addr, uint32_t length)
{
    /* Start MM2S (Memory → Stream → CNN input) */
    dma_write_reg(DMA_MM2S_CR, DMA_CR_RUN);
    dma_write_reg(DMA_MM2S_SA, src_addr);
    dma_write_reg(DMA_MM2S_LENGTH, length);  /* Triggers transfer */
    return CNN_SUCCESS;
}

static cnn_status_t dma_start_s2mm(uint32_t dst_addr, uint32_t length)
{
    /* Start S2MM (CNN output → Stream → Memory) */
    dma_write_reg(DMA_S2MM_CR, DMA_CR_RUN);
    dma_write_reg(DMA_S2MM_DA, dst_addr);
    dma_write_reg(DMA_S2MM_LENGTH, length);  /* Triggers transfer */
    return CNN_SUCCESS;
}

static cnn_status_t dma_wait_mm2s(void)
{
    volatile uint32_t *sr = (volatile uint32_t *)(DMA_BASE + DMA_MM2S_SR);

    if (wait_for_condition_timeout(sr, DMA_SR_IOC_IRQ, DMA_SR_IOC_IRQ,
                                    DMA_POLL_TIMEOUT_US) != 0) {
        xil_printf("[ERROR] DMA MM2S timeout\n");
        return CNN_ERR_TIMEOUT;
    }

    uint32_t status = dma_read_reg(DMA_MM2S_SR);
    dma_write_reg(DMA_MM2S_SR, DMA_SR_IOC_IRQ);  /* Clear IOC */

    if (status & DMA_SR_ERR_IRQ) {
        xil_printf("[ERROR] DMA MM2S error, SR=0x%08X\n", status);
        return CNN_ERR_DMA;
    }
    return CNN_SUCCESS;
}

static cnn_status_t dma_wait_s2mm(void)
{
    volatile uint32_t *sr = (volatile uint32_t *)(DMA_BASE + DMA_S2MM_SR);

    if (wait_for_condition_timeout(sr, DMA_SR_IOC_IRQ, DMA_SR_IOC_IRQ,
                                    DMA_POLL_TIMEOUT_US) != 0) {
        xil_printf("[ERROR] DMA S2MM timeout\n");
        return CNN_ERR_TIMEOUT;
    }

    uint32_t status = dma_read_reg(DMA_S2MM_SR);
    dma_write_reg(DMA_S2MM_SR, DMA_SR_IOC_IRQ);  /* Clear IOC */

    if (status & DMA_SR_ERR_IRQ) {
        xil_printf("[ERROR] DMA S2MM error, SR=0x%08X\n", status);
        return CNN_ERR_DMA;
    }
    return CNN_SUCCESS;
}

/* ============================================================================
 * CNN Accelerator control
 * ============================================================================ */

static cnn_status_t cnn_wait_idle(void)
{
    volatile uint32_t *ctrl = (volatile uint32_t *)(CNN_ACCEL_BASE + CNN_REG_CTRL);

    if (wait_for_condition_timeout(ctrl, CNN_CTRL_IDLE, CNN_CTRL_IDLE,
                                    CNN_POLL_TIMEOUT_US) != 0) {
        xil_printf("[ERROR] CNN accelerator idle timeout\n");
        return CNN_ERR_TIMEOUT;
    }
    return CNN_SUCCESS;
}

static cnn_status_t cnn_wait_done(void)
{
    volatile uint32_t *ctrl = (volatile uint32_t *)(CNN_ACCEL_BASE + CNN_REG_CTRL);

    if (wait_for_condition_timeout(ctrl, CNN_CTRL_DONE, CNN_CTRL_DONE,
                                    CNN_POLL_TIMEOUT_US) != 0) {
        xil_printf("[ERROR] CNN accelerator done timeout\n");
        return CNN_ERR_TIMEOUT;
    }
    return CNN_SUCCESS;
}

static void cnn_configure_layer(const cnn_layer_config_t *cfg)
{
    cnn_write_reg(CNN_REG_IN_H,      (uint32_t)cfg->in_h);
    cnn_write_reg(CNN_REG_IN_W,      (uint32_t)cfg->in_w);
    cnn_write_reg(CNN_REG_IN_C,      (uint32_t)cfg->in_c);
    cnn_write_reg(CNN_REG_OUT_C,     (uint32_t)cfg->out_c);
    cnn_write_reg(CNN_REG_K,         (uint32_t)cfg->k);
    cnn_write_reg(CNN_REG_STRIDE,    (uint32_t)cfg->stride);
    cnn_write_reg(CNN_REG_PAD,       (uint32_t)cfg->pad);
    cnn_write_reg(CNN_REG_ACT_SCALE, (uint32_t)cfg->act_scale);
    cnn_write_reg(CNN_REG_ACT_SHIFT, (uint32_t)cfg->act_shift);
    cnn_write_reg(CNN_REG_ACT_ZERO,  (uint32_t)cfg->act_zero);
}

/* ============================================================================
 * Public API implementation
 * ============================================================================ */

cnn_status_t cnn_accel_init(void)
{
    cnn_status_t status;

    xil_printf("[CNN] Initializing CNN accelerator...\n");

    /* Reset AXI DMA */
    status = dma_reset();
    if (status != CNN_SUCCESS) {
        xil_printf("[CNN] DMA reset failed\n");
        return status;
    }

    /* Verify CNN accelerator is idle */
    uint32_t ctrl = cnn_read_reg(CNN_REG_CTRL);
    if (!(ctrl & CNN_CTRL_IDLE)) {
        xil_printf("[CNN] Accelerator not idle after reset, CTRL=0x%08X\n", ctrl);
        /* Try a soft reset via start+wait cycle */
    }

    g_initialized = 1;
    xil_printf("[CNN] Initialization complete. CTRL=0x%08X\n", ctrl);
    return CNN_SUCCESS;
}

cnn_status_t cnn_run_layer(
    const cnn_layer_config_t *cfg,
    const int8_t  *input,
    const int8_t  *weights,
    const int32_t *bias,
    int8_t        *output)
{
    cnn_status_t status;

    if (!g_initialized) return CNN_ERR_UNINIT;
    if (!cfg || !input || !weights || !bias || !output) return CNN_ERR_INVALID_CFG;

    /* Validate configuration */
    if (cfg->in_h <= 0 || cfg->in_h > 56 ||
        cfg->in_w <= 0 || cfg->in_w > 56 ||
        cfg->in_c <= 0 || cfg->in_c > 64 ||
        cfg->out_c <= 0 || cfg->out_c > 64 ||
        cfg->k != 3 && cfg->k != 1) {
        xil_printf("[CNN] Invalid layer config\n");
        return CNN_ERR_INVALID_CFG;
    }

    /* Compute buffer sizes */
    uint32_t in_size  = (uint32_t)(cfg->in_h * cfg->in_w * cfg->in_c);
    int out_h = (cfg->in_h + 2*cfg->pad - cfg->k) / cfg->stride + 1;
    int out_w = (cfg->in_w + 2*cfg->pad - cfg->k) / cfg->stride + 1;
    uint32_t out_size = (uint32_t)(out_h * out_w * cfg->out_c);

    /* Step 1: Copy input to DMA input buffer and flush cache */
    uint8_t *dma_in_buf  = (uint8_t *)CNN_INPUT_BUF_ADDR;
    uint8_t *dma_out_buf = (uint8_t *)CNN_OUTPUT_BUF_ADDR;

    memcpy(dma_in_buf, input, in_size);
    cnn_cache_flush(CNN_INPUT_BUF_ADDR, in_size);

    /* Step 2: Configure accelerator registers */
    status = cnn_wait_idle();
    if (status != CNN_SUCCESS) return status;

    cnn_configure_layer(cfg);

    /* Step 3: Start S2MM DMA first (must be ready to accept CNN output) */
    cnn_cache_invalidate(CNN_OUTPUT_BUF_ADDR, out_size);
    status = dma_start_s2mm(CNN_OUTPUT_BUF_ADDR, out_size);
    if (status != CNN_SUCCESS) return status;

    /* Step 4: Start MM2S DMA (input data → CNN stream) */
    status = dma_start_mm2s(CNN_INPUT_BUF_ADDR, in_size);
    if (status != CNN_SUCCESS) return status;

    /* Step 5: Start CNN accelerator */
    cnn_write_reg(CNN_REG_CTRL, CNN_CTRL_START);

    /* Step 6: Wait for DMA MM2S completion */
    status = dma_wait_mm2s();
    if (status != CNN_SUCCESS) return status;

    /* Step 7: Wait for CNN accelerator done */
    status = cnn_wait_done();
    if (status != CNN_SUCCESS) return status;

    /* Step 8: Wait for DMA S2MM completion */
    status = dma_wait_s2mm();
    if (status != CNN_SUCCESS) return status;

    /* Step 9: Invalidate output cache and copy to application buffer */
    cnn_cache_invalidate(CNN_OUTPUT_BUF_ADDR, out_size);
    memcpy(output, dma_out_buf, out_size);

    return CNN_SUCCESS;
}

void cnn_accel_reset(void)
{
    /* Write start then immediately stop — hardware will reset to idle */
    cnn_write_reg(CNN_REG_CTRL, 0x00);
    dma_reset();
    g_initialized = 0;
}
