#!/usr/bin/env python3
"""
test_model.py — Unit tests for YOLOv5n model loading and inference
BECE406E FPGA-Based System Design, VIT
"""

import pytest
import numpy as np
import sys
from pathlib import Path


class TestModelLoading:
    """Tests for model initialization."""

    def test_ultralytics_import(self):
        """Ultralytics must be importable."""
        try:
            from ultralytics import YOLO
        except ImportError:
            pytest.fail("ultralytics not installed — run: pip install ultralytics")

    def test_yolov5n_load(self):
        """YOLOv5n model loads successfully (downloads if needed)."""
        from ultralytics import YOLO
        try:
            model = YOLO("yolov5n.pt")
            assert model is not None
        except Exception as e:
            pytest.skip(f"Cannot load YOLOv5n (no internet or weights): {e}")

    def test_model_has_names(self):
        """Model should have class names."""
        from ultralytics import YOLO
        try:
            model = YOLO("yolov5n.pt")
            assert hasattr(model, "names") or hasattr(model.model, "names")
            names = model.names
            assert len(names) > 0
        except Exception as e:
            pytest.skip(f"Model not available: {e}")

    def test_model_names_count_coco(self):
        """COCO model should have 80 classes."""
        from ultralytics import YOLO
        try:
            model = YOLO("yolov5n.pt")
            assert len(model.names) == 80, \
                f"Expected 80 COCO classes, got {len(model.names)}"
        except Exception as e:
            pytest.skip(f"Model not available: {e}")


class TestInferenceOutput:
    """Tests for inference output structure."""

    @pytest.fixture(scope="class")
    def model_and_image(self):
        """Load model and create a test image."""
        from ultralytics import YOLO
        import numpy as np
        try:
            model = YOLO("yolov5n.pt")
            # Synthetic 416×416 test image
            img = np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8)
            return model, img
        except Exception as e:
            pytest.skip(f"Model not available: {e}")

    def test_predict_returns_results(self, model_and_image):
        """Predict should return a list of results."""
        model, img = model_and_image
        results = model.predict(img, imgsz=416, conf=0.25, verbose=False)
        assert results is not None
        assert isinstance(results, list)
        assert len(results) > 0

    def test_results_have_boxes(self, model_and_image):
        """Results object should have a boxes attribute."""
        model, img = model_and_image
        results = model.predict(img, imgsz=416, conf=0.25, verbose=False)
        result = results[0]
        assert hasattr(result, "boxes")

    def test_boxes_tensor_shape(self, model_and_image):
        """Boxes should have shape [N, 6]: x1,y1,x2,y2,conf,cls."""
        model, img = model_and_image
        results = model.predict(img, imgsz=416, conf=0.25, verbose=False)
        result = results[0]
        if result.boxes is not None and len(result.boxes) > 0:
            data = result.boxes.data
            assert data.ndim == 2
            assert data.shape[1] == 6, f"Expected 6 columns, got {data.shape[1]}"

    def test_confidence_range(self, model_and_image):
        """Confidence scores should be in [0, 1]."""
        model, img = model_and_image
        results = model.predict(img, imgsz=416, conf=0.01, verbose=False)
        result = results[0]
        if result.boxes is not None and len(result.boxes) > 0:
            confs = result.boxes.conf.numpy()
            assert np.all(confs >= 0.0), "Confidence below 0"
            assert np.all(confs <= 1.0), "Confidence above 1"

    def test_class_ids_valid(self, model_and_image):
        """Class IDs should be valid COCO indices [0, 79]."""
        model, img = model_and_image
        results = model.predict(img, imgsz=416, conf=0.01, verbose=False)
        result = results[0]
        if result.boxes is not None and len(result.boxes) > 0:
            cls_ids = result.boxes.cls.numpy().astype(int)
            assert np.all(cls_ids >= 0), "Negative class ID"
            assert np.all(cls_ids <= 79), f"Class ID > 79: {cls_ids.max()}"

    def test_boxes_within_image(self, model_and_image):
        """Bounding boxes should be within image bounds."""
        model, img = model_and_image
        h, w = img.shape[:2]
        results = model.predict(img, imgsz=416, conf=0.01, verbose=False)
        result = results[0]
        if result.boxes is not None and len(result.boxes) > 0:
            xyxy = result.boxes.xyxy.numpy()
            # Scale may differ — check relative to original image
            orig_shape = result.orig_shape
            oh, ow = orig_shape[0], orig_shape[1]
            assert np.all(xyxy[:, 0] >= 0), "x1 < 0"
            assert np.all(xyxy[:, 1] >= 0), "y1 < 0"
            assert np.all(xyxy[:, 2] <= ow * 1.05), f"x2 > image width {ow}"
            assert np.all(xyxy[:, 3] <= oh * 1.05), f"y2 > image height {oh}"

    def test_conf_threshold_respected(self, model_and_image):
        """No detection should have confidence below threshold."""
        model, img = model_and_image
        threshold = 0.50
        results = model.predict(img, imgsz=416, conf=threshold, verbose=False)
        result = results[0]
        if result.boxes is not None and len(result.boxes) > 0:
            confs = result.boxes.conf.numpy()
            assert np.all(confs >= threshold - 1e-4), \
                f"Found detections below threshold {threshold}: {confs.min():.4f}"

    def test_different_input_sizes(self):
        """Model should work with different input sizes."""
        from ultralytics import YOLO
        try:
            model = YOLO("yolov5n.pt")
        except Exception as e:
            pytest.skip(f"Model not available: {e}")

        for size in [320, 416, 640]:
            img = np.random.randint(0, 256, (size, size, 3), dtype=np.uint8)
            results = model.predict(img, imgsz=size, conf=0.25, verbose=False)
            assert results is not None, f"Failed for size {size}"

    def test_batch_inference(self):
        """Model should handle a list of images."""
        from ultralytics import YOLO
        try:
            model = YOLO("yolov5n.pt")
        except Exception as e:
            pytest.skip(f"Model not available: {e}")

        imgs = [
            np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8),
            np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8),
        ]
        results = model.predict(imgs, imgsz=416, conf=0.25, verbose=False)
        assert len(results) == 2


class TestModelPerformance:
    """Performance tests — validate timing and throughput."""

    def test_inference_time_reasonable(self):
        """CPU inference should complete in < 30 seconds per frame."""
        import time
        from ultralytics import YOLO
        try:
            model = YOLO("yolov5n.pt")
        except Exception as e:
            pytest.skip(f"Model not available: {e}")

        img = np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8)

        # Warmup
        model.predict(img, imgsz=416, conf=0.25, verbose=False)

        # Time one pass
        t0 = time.perf_counter()
        model.predict(img, imgsz=416, conf=0.25, verbose=False)
        t1 = time.perf_counter()

        elapsed_ms = (t1 - t0) * 1000
        print(f"\n  CPU inference time: {elapsed_ms:.1f} ms ({1000/elapsed_ms:.1f} FPS)")
        print(f"  FPGA target: ≥25 FPS")

        # Just warn if slow, don't fail (depends on CPU)
        if elapsed_ms > 30000:
            pytest.fail(f"Inference took {elapsed_ms:.0f} ms — likely stalled")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
