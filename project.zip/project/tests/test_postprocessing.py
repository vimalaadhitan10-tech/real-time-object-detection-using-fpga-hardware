#!/usr/bin/env python3
"""
test_postprocessing.py — Unit tests for YOLO detection postprocessing
BECE406E FPGA-Based System Design, VIT
"""

import pytest
import numpy as np
import sys
from pathlib import Path


# ============================================================================
# NMS and detection postprocessing (matches ARM main.c logic)
# ============================================================================

def compute_iou(box1: np.ndarray, box2: np.ndarray) -> float:
    """
    Compute IoU between two boxes [x1, y1, x2, y2].
    Matches the iou() function in software/baremetal/main.c.
    """
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])

    inter_w = x2 - x1
    inter_h = y2 - y1
    if inter_w <= 0 or inter_h <= 0:
        return 0.0

    inter_area = inter_w * inter_h
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    union_area = area1 + area2 - inter_area

    if union_area <= 0:
        return 0.0
    return inter_area / union_area


def nms(boxes: np.ndarray, scores: np.ndarray, iou_threshold: float) -> np.ndarray:
    """
    Greedy NMS — mirrors nms() in software/baremetal/main.c.
    boxes: [N, 4] array of [x1, y1, x2, y2]
    scores: [N] confidence scores
    Returns: indices of kept boxes (sorted by score descending)
    """
    if len(boxes) == 0:
        return np.array([], dtype=int)

    order = np.argsort(scores)[::-1]
    kept = []

    while len(order) > 0:
        i = order[0]
        kept.append(i)

        if len(order) == 1:
            break

        ious = np.array([compute_iou(boxes[i], boxes[j]) for j in order[1:]])
        order = order[1:][ious <= iou_threshold]

    return np.array(kept, dtype=int)


def decode_yolo_anchor(tx: float, ty: float, tw: float, th: float,
                        anchor_w: float, anchor_h: float,
                        grid_x: int, grid_y: int, stride: int) -> tuple:
    """
    Decode YOLO raw prediction to (cx, cy, w, h) in image coordinates.
    tx, ty: raw x, y predictions (before sigmoid)
    tw, th: raw w, h predictions (before exp)
    """
    cx = (float(grid_x) + 1.0 / (1.0 + np.exp(-tx))) * stride
    cy = (float(grid_y) + 1.0 / (1.0 + np.exp(-ty))) * stride
    w  = np.exp(tw) * anchor_w
    h  = np.exp(th) * anchor_h
    return cx, cy, w, h


def xywh_to_xyxy(cx: float, cy: float, w: float, h: float) -> tuple:
    """Convert center-format to corner-format bounding box."""
    x1 = cx - w / 2
    y1 = cy - h / 2
    x2 = cx + w / 2
    y2 = cy + h / 2
    return x1, y1, x2, y2


# ============================================================================
# Tests: IoU computation
# ============================================================================

class TestIoU:
    def test_identical_boxes(self):
        """Identical boxes should have IoU = 1.0."""
        box = np.array([0, 0, 100, 100], dtype=float)
        assert abs(compute_iou(box, box) - 1.0) < 1e-6

    def test_no_overlap(self):
        """Non-overlapping boxes should have IoU = 0.0."""
        box1 = np.array([0, 0, 10, 10], dtype=float)
        box2 = np.array([20, 20, 30, 30], dtype=float)
        assert compute_iou(box1, box2) == 0.0

    def test_partial_overlap(self):
        """Half-overlapping squares of equal size: IoU = 1/3."""
        box1 = np.array([0, 0, 10, 10], dtype=float)
        box2 = np.array([5, 0, 15, 10], dtype=float)
        expected = 50.0 / 150.0  # intersection=50, union=150
        assert abs(compute_iou(box1, box2) - expected) < 1e-6

    def test_symmetry(self):
        """IoU(A, B) == IoU(B, A)."""
        box1 = np.array([0, 0, 50, 50], dtype=float)
        box2 = np.array([25, 25, 75, 75], dtype=float)
        assert abs(compute_iou(box1, box2) - compute_iou(box2, box1)) < 1e-9

    def test_contained_box(self):
        """Inner box fully inside outer: IoU = inner_area / outer_area."""
        outer = np.array([0, 0, 100, 100], dtype=float)
        inner = np.array([25, 25, 75, 75], dtype=float)
        expected = 2500.0 / 10000.0  # 0.25
        assert abs(compute_iou(outer, inner) - expected) < 1e-6

    def test_iou_range(self):
        """IoU must always be in [0, 1]."""
        for _ in range(100):
            np.random.seed(42)
            coords = np.random.uniform(0, 100, (2, 4))
            for row in coords:
                row[0], row[2] = min(row[0], row[2]), max(row[0], row[2])
                row[1], row[3] = min(row[1], row[3]), max(row[1], row[3])
            iou = compute_iou(coords[0], coords[1])
            assert 0.0 <= iou <= 1.0

    def test_touching_boxes_no_overlap(self):
        """Boxes that touch at an edge should have IoU = 0 (no area overlap)."""
        box1 = np.array([0, 0, 10, 10], dtype=float)
        box2 = np.array([10, 0, 20, 10], dtype=float)
        assert compute_iou(box1, box2) == 0.0


# ============================================================================
# Tests: NMS
# ============================================================================

class TestNMS:
    def test_single_box(self):
        """Single box should always be kept."""
        boxes  = np.array([[0, 0, 10, 10]], dtype=float)
        scores = np.array([0.9])
        kept = nms(boxes, scores, iou_threshold=0.5)
        assert len(kept) == 1
        assert kept[0] == 0

    def test_no_boxes(self):
        """Empty input returns empty array."""
        kept = nms(np.zeros((0, 4)), np.zeros(0), 0.5)
        assert len(kept) == 0

    def test_suppress_duplicate(self):
        """Duplicate boxes → only highest-confidence one kept."""
        boxes  = np.array([[0, 0, 10, 10],
                           [0, 0, 10, 10]], dtype=float)
        scores = np.array([0.9, 0.7])
        kept = nms(boxes, scores, iou_threshold=0.5)
        assert len(kept) == 1
        assert kept[0] == 0  # Highest score wins

    def test_non_overlapping_both_kept(self):
        """Non-overlapping boxes should both be kept."""
        boxes  = np.array([[0, 0, 10, 10],
                           [50, 50, 60, 60]], dtype=float)
        scores = np.array([0.9, 0.8])
        kept = nms(boxes, scores, iou_threshold=0.5)
        assert len(kept) == 2

    def test_high_iou_threshold_keeps_more(self):
        """High IoU threshold keeps more overlapping boxes."""
        boxes  = np.array([[0, 0, 100, 100],
                           [10, 10, 90, 90],
                           [200, 200, 300, 300]], dtype=float)
        scores = np.array([0.9, 0.8, 0.7])
        kept_low  = nms(boxes, scores, iou_threshold=0.3)
        kept_high = nms(boxes, scores, iou_threshold=0.9)
        assert len(kept_high) >= len(kept_low)

    def test_nms_conf_threshold_0_45(self):
        """Standard YOLO IoU threshold 0.45."""
        boxes  = np.array([[0, 0, 100, 100],
                           [5, 5, 95, 95],    # 88% IoU with box0
                           [200, 200, 300, 300]], dtype=float)
        scores = np.array([0.9, 0.8, 0.7])
        kept = nms(boxes, scores, iou_threshold=0.45)
        # box1 has IoU>0.45 with box0 → suppressed; box2 kept
        assert 0 in kept
        assert 2 in kept
        assert 1 not in kept

    def test_nms_sorted_by_score(self):
        """Highest-score box should always survive."""
        np.random.seed(42)
        boxes  = np.random.uniform(0, 100, (5, 4))
        boxes[:, 2] = boxes[:, 0] + 20
        boxes[:, 3] = boxes[:, 1] + 20
        scores = np.random.rand(5)
        kept = nms(boxes, scores, iou_threshold=0.5)
        best_idx = np.argmax(scores)
        assert best_idx in kept, "Highest-score box must be kept"


# ============================================================================
# Tests: YOLO anchor decoding
# ============================================================================

class TestAnchorDecode:
    def test_zero_offset(self):
        """tx=ty=0 means box center is at grid_x+0.5, grid_y+0.5."""
        cx, cy, w, h = decode_yolo_anchor(0, 0, 0, 0, 10, 10, 2, 3, 16)
        assert abs(cx - (2.5 * 16)) < 1e-3
        assert abs(cy - (3.5 * 16)) < 1e-3

    def test_width_height_positive(self):
        """Decoded width and height should always be positive."""
        for tw in [-2, -1, 0, 1, 2]:
            for th in [-2, -1, 0, 1, 2]:
                _, _, w, h = decode_yolo_anchor(0, 0, tw, th, 30, 30, 0, 0, 32)
                assert w > 0, f"Width ≤ 0 for tw={tw}"
                assert h > 0, f"Height ≤ 0 for th={th}"

    def test_xywh_to_xyxy_correct(self):
        """Center format conversion to corner format."""
        x1, y1, x2, y2 = xywh_to_xyxy(50, 50, 20, 30)
        assert x1 == 40
        assert y1 == 35
        assert x2 == 60
        assert y2 == 65

    def test_xyxy_box_valid(self):
        """x1 < x2 and y1 < y2."""
        x1, y1, x2, y2 = xywh_to_xyxy(100, 100, 50, 60)
        assert x1 < x2
        assert y1 < y2

    def test_box_area_positive(self):
        """Box area must be positive."""
        x1, y1, x2, y2 = xywh_to_xyxy(50, 50, 20, 20)
        area = (x2 - x1) * (y2 - y1)
        assert area > 0


# ============================================================================
# Tests: Detection pipeline integration
# ============================================================================

class TestDetectionPipeline:
    def test_filter_by_confidence(self):
        """Only detections above threshold should pass."""
        scores    = np.array([0.9, 0.3, 0.6, 0.1, 0.8])
        threshold = 0.5
        filtered  = scores[scores >= threshold]
        assert len(filtered) == 3
        assert np.all(filtered >= threshold)

    def test_detection_structure(self):
        """Detection dict should have required keys."""
        det = {"x1": 0, "y1": 0, "x2": 100, "y2": 100, "conf": 0.9, "class_id": 0}
        for key in ["x1", "y1", "x2", "y2", "conf", "class_id"]:
            assert key in det

    def test_class_id_bounds(self):
        """Class IDs should be in [0, num_classes-1] = [0, 79] for COCO."""
        class_ids = np.array([0, 1, 39, 79])
        assert np.all(class_ids >= 0)
        assert np.all(class_ids <= 79)

    def test_bounding_box_within_image(self):
        """Clamp boxes to image dimensions."""
        img_h, img_w = 416, 416
        boxes = np.array([[-5, -5, 100, 100],
                          [400, 400, 420, 420]])
        clamped = np.clip(boxes, [0, 0, 0, 0], [img_w, img_h, img_w, img_h])
        assert np.all(clamped[:, 0] >= 0)
        assert np.all(clamped[:, 1] >= 0)
        assert np.all(clamped[:, 2] <= img_w)
        assert np.all(clamped[:, 3] <= img_h)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
