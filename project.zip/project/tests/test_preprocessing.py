#!/usr/bin/env python3
"""
test_preprocessing.py — Unit tests for image preprocessing pipeline
BECE406E FPGA-Based System Design, VIT
"""

import pytest
import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "model"))


# ============================================================================
# Preprocessing functions (mirrors the ARM software preprocess_image() in main.c
# and the expected input format for the HLS accelerator)
# ============================================================================

def resize_nearest(img: np.ndarray, target_h: int, target_w: int) -> np.ndarray:
    """Nearest-neighbor resize — matches ARM implementation."""
    in_h, in_w = img.shape[:2]
    scale_h = in_h / target_h
    scale_w = in_w / target_w
    out = np.zeros((target_h, target_w, img.shape[2]), dtype=img.dtype)
    for h in range(target_h):
        for w in range(target_w):
            src_h = min(int(h * scale_h), in_h - 1)
            src_w = min(int(w * scale_w), in_w - 1)
            out[h, w] = img[src_h, src_w]
    return out


def normalize_to_int8(img_hwc: np.ndarray) -> np.ndarray:
    """
    Normalize uint8 HWC → INT8 CHW for accelerator.
    Scale: pixel / 255 → [-128, 127]
    zero_point = -128 (matches quantize.py preprocess_image in main.c)
    """
    assert img_hwc.dtype == np.uint8
    assert img_hwc.ndim == 3
    H, W, C = img_hwc.shape
    out = np.zeros((C, H, W), dtype=np.int8)
    for c in range(C):
        channel = img_hwc[:, :, c].astype(np.int32) - 128
        out[c] = np.clip(channel, -128, 127).astype(np.int8)
    return out


def hwc_to_chw(arr: np.ndarray) -> np.ndarray:
    """Convert HWC to CHW layout."""
    assert arr.ndim == 3
    return np.transpose(arr, (2, 0, 1))


# ============================================================================
# Tests
# ============================================================================

class TestResize:
    def test_resize_identity(self):
        """Image of target size should remain unchanged."""
        img = np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8)
        out = resize_nearest(img, 416, 416)
        assert out.shape == (416, 416, 3)
        np.testing.assert_array_equal(img, out)

    def test_resize_downscale(self):
        """Downscaling from 640×480 to 416×416."""
        img = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
        out = resize_nearest(img, 416, 416)
        assert out.shape == (416, 416, 3), f"Expected (416,416,3), got {out.shape}"
        assert out.dtype == np.uint8

    def test_resize_upscale(self):
        """Upscaling from small image."""
        img = np.random.randint(0, 256, (100, 100, 3), dtype=np.uint8)
        out = resize_nearest(img, 416, 416)
        assert out.shape == (416, 416, 3)

    def test_resize_single_channel(self):
        """Single-channel image."""
        img = np.random.randint(0, 256, (224, 224, 1), dtype=np.uint8)
        out = resize_nearest(img, 112, 112)
        assert out.shape == (112, 112, 1)

    def test_resize_output_dtype(self):
        """Output should maintain input dtype."""
        img = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
        out = resize_nearest(img, 320, 320)
        assert out.dtype == np.uint8

    def test_resize_corner_pixel(self):
        """Top-left pixel should be preserved in nearest-neighbor."""
        img = np.zeros((100, 100, 3), dtype=np.uint8)
        img[0, 0] = [255, 0, 0]
        out = resize_nearest(img, 50, 50)
        # Nearest-neighbor: (0,0) → (0,0)
        assert int(out[0, 0, 0]) == 255
        assert int(out[0, 0, 1]) == 0


class TestNormalization:
    def test_zero_pixel_maps_to_minus128(self):
        """Pixel value 0 → INT8 -128."""
        img = np.zeros((1, 1, 1), dtype=np.uint8)
        out = normalize_to_int8(img)
        assert int(out[0, 0, 0]) == -128

    def test_255_pixel_maps_to_127(self):
        """Pixel value 255 → INT8 127."""
        img = np.full((1, 1, 1), 255, dtype=np.uint8)
        out = normalize_to_int8(img)
        assert int(out[0, 0, 0]) == 127

    def test_128_pixel_maps_to_zero(self):
        """Pixel value 128 → INT8 0."""
        img = np.full((1, 1, 1), 128, dtype=np.uint8)
        out = normalize_to_int8(img)
        assert int(out[0, 0, 0]) == 0

    def test_output_range_valid(self):
        """All output values should be in [-128, 127]."""
        img = np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8)
        out = normalize_to_int8(img)
        assert out.min() >= -128
        assert out.max() <= 127

    def test_output_dtype(self):
        """Output should be INT8."""
        img = np.random.randint(0, 256, (10, 10, 3), dtype=np.uint8)
        out = normalize_to_int8(img)
        assert out.dtype == np.int8

    def test_output_shape_chw(self):
        """Output should be in CHW format (C, H, W)."""
        img = np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8)
        out = normalize_to_int8(img)
        assert out.shape == (3, 416, 416), f"Expected (3,416,416), got {out.shape}"

    def test_monotonic_mapping(self):
        """Pixel 100 should map between -128 and 127 monotonically."""
        img_low  = np.full((1, 1, 1), 100, dtype=np.uint8)
        img_high = np.full((1, 1, 1), 200, dtype=np.uint8)
        out_low  = normalize_to_int8(img_low)
        out_high = normalize_to_int8(img_high)
        assert int(out_low[0, 0, 0]) < int(out_high[0, 0, 0])


class TestLayoutConversion:
    def test_hwc_to_chw_shape(self):
        """HWC (416,416,3) → CHW (3,416,416)."""
        arr = np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8)
        out = hwc_to_chw(arr)
        assert out.shape == (3, 416, 416)

    def test_hwc_to_chw_values(self):
        """Values should be preserved during layout conversion."""
        arr = np.arange(27, dtype=np.uint8).reshape(3, 3, 3)
        out = hwc_to_chw(arr)
        # Check specific element: arr[0,0,0] == out[0,0,0]
        assert int(arr[0, 0, 0]) == int(out[0, 0, 0])
        assert int(arr[0, 0, 1]) == int(out[1, 0, 0])
        assert int(arr[0, 0, 2]) == int(out[2, 0, 0])


class TestEndToEnd:
    def test_full_pipeline_shape(self):
        """Full preprocessing: raw image → INT8 CHW tensor for accelerator."""
        raw = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
        resized = resize_nearest(raw, 416, 416)
        tensor = normalize_to_int8(resized)
        assert tensor.shape == (3, 416, 416)
        assert tensor.dtype == np.int8
        assert tensor.min() >= -128
        assert tensor.max() <= 127

    def test_deterministic(self):
        """Same input must produce same output (no randomness)."""
        np.random.seed(42)
        raw = np.random.randint(0, 256, (416, 416, 3), dtype=np.uint8)
        out1 = normalize_to_int8(resize_nearest(raw, 416, 416))
        out2 = normalize_to_int8(resize_nearest(raw, 416, 416))
        np.testing.assert_array_equal(out1, out2)

    def test_320x320_input_size(self):
        """320×320 input size should also work (alternative FPGA config)."""
        raw = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
        resized = resize_nearest(raw, 320, 320)
        tensor = normalize_to_int8(resized)
        assert tensor.shape == (3, 320, 320)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
