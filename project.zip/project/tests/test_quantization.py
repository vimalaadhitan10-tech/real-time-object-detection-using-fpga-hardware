#!/usr/bin/env python3
"""
test_quantization.py — Unit tests for INT8 quantization pipeline
BECE406E FPGA-Based System Design, VIT
"""

import pytest
import numpy as np
import sys
from pathlib import Path


# ============================================================================
# Quantization math functions (mirrors conv_engine.cpp requantize())
# ============================================================================

def requantize(acc: int, scale: int, shift: int, zero: int) -> int:
    """
    INT8 requantization — mirrors conv_engine.cpp requantize().
    acc: INT32 accumulator
    scale: Q0.N multiplier
    shift: right-shift amount
    zero: output zero-point
    """
    scaled = (acc * scale) >> shift
    scaled += zero
    return int(np.clip(scaled, -128, 127))


def quantize_tensor(fp32: np.ndarray, scale: float, zero_point: int) -> np.ndarray:
    """Quantize FP32 tensor to INT8 using affine quantization."""
    q = np.round(fp32 / scale) + zero_point
    return np.clip(q, -128, 127).astype(np.int8)


def dequantize_tensor(q: np.ndarray, scale: float, zero_point: int) -> np.ndarray:
    """Dequantize INT8 tensor to FP32."""
    return (q.astype(np.float32) - zero_point) * scale


def compute_scale_zero(min_val: float, max_val: float, bits: int = 8) -> tuple:
    """Compute INT8 quantization scale and zero_point from min/max range."""
    qmin = -(2**(bits-1))       # -128
    qmax = (2**(bits-1)) - 1    # 127
    scale = (max_val - min_val) / (qmax - qmin)
    zero_point = qmin - round(min_val / scale)
    zero_point = int(np.clip(zero_point, qmin, qmax))
    return scale, zero_point


# ============================================================================
# Tests: requantize() — mirrors conv_engine.cpp
# ============================================================================

class TestRequantize:
    """Tests that mirror the HLS requantize() function exactly."""

    def test_identity_scale_shift_zero(self):
        """requantize(acc=5, scale=1, shift=0, zero=0) = 5."""
        assert requantize(5, 1, 0, 0) == 5

    def test_positive_saturation(self):
        """Large positive acc should saturate to 127."""
        assert requantize(1000, 1, 0, 0) == 127

    def test_negative_saturation(self):
        """Large negative acc should saturate to -128."""
        assert requantize(-1000, 1, 0, 0) == -128

    def test_zero_accumulator(self):
        """Zero accumulator + zero zero_point → 0."""
        assert requantize(0, 1, 0, 0) == 0

    def test_with_shift(self):
        """requantize(256, scale=1, shift=8, zero=0) = 1."""
        assert requantize(256, 1, 8, 0) == 1

    def test_with_zero_point(self):
        """Zero point shifts output."""
        result = requantize(0, 1, 0, 10)
        assert result == 10

    def test_saturation_at_127_boundary(self):
        """acc=127 should NOT saturate."""
        assert requantize(127, 1, 0, 0) == 127

    def test_saturation_at_minus128_boundary(self):
        """acc=-128 should NOT saturate."""
        assert requantize(-128, 1, 0, 0) == -128

    def test_saturation_at_128_triggers(self):
        """acc=128 SHOULD saturate to 127."""
        assert requantize(128, 1, 0, 0) == 127

    def test_saturation_at_minus129_triggers(self):
        """acc=-129 SHOULD saturate to -128."""
        assert requantize(-129, 1, 0, 0) == -128

    def test_conv_example_3x3(self):
        """
        Realistic test: 3×3 conv with all input=2, all weight=1, no bias.
        acc = 2 * 1 * 9 = 18, scale=1, shift=0, zero=0 → 18
        """
        acc = 2 * 1 * 9  # input × weight × kernel_area
        result = requantize(acc, 1, 0, 0)
        assert result == 18

    def test_conv_large_channels(self):
        """
        Test with 64 channels, to verify no overflow path:
        acc = 64 * 127 * 127 * 9 = 93,175,296 → after scale=1,shift=20 → clipped
        """
        acc = 64 * 127 * 127 * 9
        # With shift=20: 93175296 >> 20 = 88 → within INT8 range
        result = requantize(acc, 1, 20, 0)
        assert -128 <= result <= 127

    def test_matches_reference_model(self):
        """Test several cases against NumPy reference."""
        test_cases = [
            (0,    1, 0, 0,    0),
            (127,  1, 0, 0,  127),
            (-128, 1, 0, 0, -128),
            (1000, 1, 0, 0,  127),
            (256,  1, 8, 0,    1),
            (0,    1, 0, 5,    5),
        ]
        for acc, scale, shift, zero, expected in test_cases:
            got = requantize(acc, scale, shift, zero)
            assert got == expected, \
                f"requantize({acc},{scale},{shift},{zero}): expected {expected}, got {got}"


# ============================================================================
# Tests: Affine quantization (scale + zero_point)
# ============================================================================

class TestAffineQuantization:
    def test_quantize_range(self):
        """Quantized values should be in INT8 range."""
        fp32 = np.random.randn(100).astype(np.float32) * 2.0
        scale, zp = compute_scale_zero(float(fp32.min()), float(fp32.max()))
        q = quantize_tensor(fp32, scale, zp)
        assert q.min() >= -128
        assert q.max() <= 127

    def test_dequantize_roundtrip_error(self):
        """Quantize → dequantize error should be bounded by quantization step."""
        fp32 = np.linspace(-1.0, 1.0, 1000).astype(np.float32)
        scale, zp = compute_scale_zero(-1.0, 1.0)
        q    = quantize_tensor(fp32, scale, zp)
        deq  = dequantize_tensor(q, scale, zp)
        err  = np.abs(fp32 - deq)
        max_err = scale  # Maximum quantization error = 1 LSB
        assert err.max() <= max_err * 1.1, \
            f"Max error {err.max():.4f} exceeds 1 LSB ({max_err:.4f})"

    def test_zero_maps_to_zero_point(self):
        """fp32=0.0 should map to the zero_point."""
        scale, zp = compute_scale_zero(-1.0, 1.0)
        q = quantize_tensor(np.array([0.0], dtype=np.float32), scale, zp)
        assert int(q[0]) == zp

    def test_scale_positive(self):
        """Scale must always be positive."""
        for _ in range(10):
            fp32 = np.random.randn(100).astype(np.float32)
            scale, _ = compute_scale_zero(float(fp32.min()), float(fp32.max()))
            assert scale > 0

    def test_int8_mAP_drop_within_budget(self):
        """
        Simulate quantization impact on detection confidence.
        FP32 vs INT8 confidence should differ by at most ~2%.
        Uses synthetic detection scores (real mAP requires COCO dataset).
        """
        # Simulated FP32 confidence scores from model
        np.random.seed(42)
        fp32_scores = np.clip(np.random.randn(100) * 0.2 + 0.7, 0, 1).astype(np.float32)

        # Quantize and dequantize (simulates INT8 quantization effect)
        scale, zp = compute_scale_zero(0.0, 1.0)
        q    = quantize_tensor(fp32_scores, scale, zp)
        deq  = dequantize_tensor(q, scale, zp)

        # Compute "mAP drop proxy": mean absolute difference in confidence
        conf_diff = np.abs(fp32_scores - deq).mean()

        # For an 8-bit quantization of [0,1] range:
        # scale = 1/255 ≈ 0.0039; expected conf_diff < 0.5%
        assert conf_diff < 0.01, \
            f"Confidence diff {conf_diff:.4f} suggests >1% accuracy drop"

    def test_activation_distribution_preserved(self):
        """
        Mean and std of dequantized tensor should be close to FP32 original.
        Checks that quantization doesn't significantly bias the distribution.
        """
        np.random.seed(0)
        fp32 = np.random.randn(10000).astype(np.float32) * 0.5
        scale, zp = compute_scale_zero(float(fp32.min()), float(fp32.max()))
        q   = quantize_tensor(fp32, scale, zp)
        deq = dequantize_tensor(q, scale, zp)

        assert abs(fp32.mean() - deq.mean()) < 0.01, "Mean significantly changed"
        assert abs(fp32.std() - deq.std()) < 0.02,   "Std significantly changed"


# ============================================================================
# Tests: HLS-specific quantization math
# ============================================================================

class TestHLSQuantizationMath:
    """Verify the integer arithmetic used in the HLS accelerator."""

    def test_int8_mac_no_overflow_small(self):
        """
        INT8 × INT8 MAC: -128 × -128 = 16384.
        Should fit in INT32 (max INT32 = 2,147,483,647).
        After 220 DSP MACs: 220 × 16384 = 3,604,480 — within INT32.
        """
        max_product = 128 * 128 * 220 * 9  # 9 = 3×3 kernel
        assert max_product < 2**31, f"Overflow: {max_product} > INT32_MAX"

    def test_int8_mac_worst_case(self):
        """
        Worst-case accumulation: 64 channels × 3×3 kernel × max(|input| × |weight|)
        = 64 × 9 × 127 × 127 = 9,288,576 — well within INT32.
        """
        worst_case = 64 * 9 * 127 * 127
        assert worst_case < 2**31, f"Overflow: {worst_case}"
        print(f"\n  Worst-case INT32 accumulator: {worst_case:,} (INT32_MAX={2**31-1:,})")

    def test_int8_weight_range(self):
        """INT8 weights should represent [-128, 127]."""
        assert np.iinfo(np.int8).min == -128
        assert np.iinfo(np.int8).max == 127

    def test_int32_accumulator_range(self):
        """INT32 accumulator range check."""
        assert np.iinfo(np.int32).min == -2147483648
        assert np.iinfo(np.int32).max ==  2147483647

    def test_pe_simd_dsp_utilization(self):
        """
        PE=8, SIMD=8 → 64 parallel MACs.
        64 < 220 (XC7Z020 DSP48E1 budget).
        """
        PE = 8
        SIMD = 8
        active_dsps = PE * SIMD
        xc7z020_dsps = 220
        assert active_dsps <= xc7z020_dsps, \
            f"PE×SIMD={active_dsps} exceeds XC7Z020 DSPs ({xc7z020_dsps})"
        print(f"\n  DSP utilization: {active_dsps}/{xc7z020_dsps} = {active_dsps/xc7z020_dsps:.0%}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
